#!/usr/bin/env python3
"""
Generator syntetycznych plików pcap do testowania pcapan.
Każdy plik zawiera znany scenariusz, więc wiadomo, co program powinien wykryć.

    normal.pcap         - zwykły ruch WWW + DNS (oczekiwane: brak alarmów)
    portscan.pcap       - skan SYN 200 portów + pakiety NULL/XMAS
    synflood.pcap       - SYN flood ze sfałszowanych adresów
    amplification.pcap  - odbicie DNS ze wzmocnieniem
    mixed.pcap          - wszystko naraz + IPv6, VLAN, zero window, retransmisje,
                          skok ruchu, telnet, obcięte pakiety

Użycie: python3 gen_pcaps.py KATALOG
"""
import os
import random
import sys

from scapy.all import (DNS, DNSQR, IP, TCP, UDP, Dot1Q, Ether, IPv6, Raw,
                       wrpcap)

random.seed(7)
T0 = 1_763_900_000.0   # stały punkt startowy => powtarzalne wyniki
MAC_C = "02:00:00:00:00:01"
MAC_S = "02:00:00:00:00:02"


def eth(pkt, vlan=None):
    if vlan is not None:
        return Ether(src=MAC_C, dst=MAC_S) / Dot1Q(vlan=vlan) / pkt
    return Ether(src=MAC_C, dst=MAC_S) / pkt


def stamp(pkt, t):
    pkt.time = t
    return pkt


def tcp_session(cli, sport, srv, dport, t, rtt=0.02, segs=10, size=1200,
                loss=0.0, close="fin", resp_ratio=1.0, v6=False, vlan=None,
                zero_window=0):
    """Pełna sesja TCP: handshake, wymiana danych, zamknięcie."""
    L3 = IPv6 if v6 else IP
    out = []
    cseq, sseq = random.randint(0, 2**32 - 1), random.randint(0, 2**32 - 1)

    def c2s(flags, payload=b"", seq=None, win=64240):
        p = eth(L3(src=cli, dst=srv) / TCP(sport=sport, dport=dport, flags=flags,
                                             seq=cseq if seq is None else seq,
                                             ack=sseq, window=win) / Raw(payload), vlan)
        return p

    def s2c(flags, payload=b"", seq=None, win=65535):
        return eth(L3(src=srv, dst=cli) / TCP(sport=dport, dport=sport, flags=flags,
                                               seq=sseq if seq is None else seq,
                                               ack=cseq, window=win) / Raw(payload), vlan)

    out.append(stamp(c2s("S"), t)); cseq = (cseq + 1) % 2**32
    t += rtt / 2
    out.append(stamp(s2c("SA"), t)); sseq = (sseq + 1) % 2**32
    t += rtt / 2
    out.append(stamp(c2s("A"), t))

    req = b"GET / HTTP/1.1\r\nHost: x\r\n\r\n"
    t += 0.001
    out.append(stamp(c2s("PA", req), t)); cseq = (cseq + len(req)) % 2**32

    for i in range(segs):
        t += 0.0008
        data = bytes(int(size * resp_ratio))
        out.append(stamp(s2c("A", data), t))
        if random.random() < loss:          # utracony segment -> retransmisja
            t += rtt * 3
            out.append(stamp(s2c("A", data), t))
        sseq = (sseq + len(data)) % 2**32
        if i % 2:
            t += 0.0003
            win = 0 if zero_window and i < zero_window * 2 else 64240
            out.append(stamp(c2s("A", win=win), t))

    t += 0.01
    if close == "fin":
        out.append(stamp(s2c("FA"), t)); sseq = (sseq + 1) % 2**32
        t += rtt / 2
        out.append(stamp(c2s("FA"), t)); cseq = (cseq + 1) % 2**32
        t += rtt / 2
        out.append(stamp(s2c("A"), t))
    elif close == "rst":
        out.append(stamp(c2s("R"), t))
    return out, t


def dns_pair(cli, srv, t, name="example.com", resp_size=90, sport=None):
    sport = sport or random.randint(1024, 65000)
    q = stamp(eth(IP(src=cli, dst=srv) / UDP(sport=sport, dport=53) /
                  DNS(rd=1, qd=DNSQR(qname=name))), t)
    r = stamp(eth(IP(src=srv, dst=cli) / UDP(sport=53, dport=sport) /
                  Raw(bytes(resp_size))), t + 0.015)
    return [q, r]


def normal_traffic(t_start, dur, clients=8, servers=None, rate=2.0):
    servers = servers or ["93.184.216.34", "142.250.74.78", "151.101.1.69", "104.16.132.229"]
    pk = []
    t = t_start
    while t < t_start + dur:
        cli = f"192.168.1.{random.randint(10, 10 + clients)}"
        srv = random.choice(servers)
        pk += dns_pair(cli, "192.168.1.1", t)
        s, _ = tcp_session(cli, random.randint(40000, 60000), srv, random.choice([443, 443, 80]),
                           t + 0.03, rtt=random.uniform(0.01, 0.08), segs=random.randint(4, 30))
        pk += s
        t += random.expovariate(rate)
    return pk


def portscan(t, attacker="10.66.6.6", victim="192.168.1.20", nports=200):
    pk = []
    open_ports = {22, 80, 443}
    for i, port in enumerate(random.sample(range(1, 1025), nports) + [22, 80, 443]):
        sp = random.randint(40000, 60000)
        tt = t + i * 0.002
        pk.append(stamp(eth(IP(src=attacker, dst=victim) /
                            TCP(sport=sp, dport=port, flags="S", seq=1000)), tt))
        if port in open_ports:
            pk.append(stamp(eth(IP(src=victim, dst=attacker) /
                                TCP(sport=port, dport=sp, flags="SA", seq=5000, ack=1001)), tt + 0.0005))
            pk.append(stamp(eth(IP(src=attacker, dst=victim) /
                                TCP(sport=sp, dport=port, flags="R", seq=1001)), tt + 0.0008))
        else:
            pk.append(stamp(eth(IP(src=victim, dst=attacker) /
                                TCP(sport=port, dport=sp, flags="RA", seq=0, ack=1001)), tt + 0.0005))
    # NULL i XMAS
    for i, port in enumerate(range(20, 40)):
        pk.append(stamp(eth(IP(src=attacker, dst=victim) /
                            TCP(sport=55555, dport=port, flags="")), t + 1 + i * 0.01))
        pk.append(stamp(eth(IP(src=attacker, dst=victim) /
                            TCP(sport=55556, dport=port, flags="FPU")), t + 1.005 + i * 0.01))
    # skan poziomy: port 3389 na 40 hostach
    for h in range(40):
        pk.append(stamp(eth(IP(src=attacker, dst=f"192.168.2.{h + 1}") /
                            TCP(sport=50000 + h, dport=3389, flags="S")), t + 2 + h * 0.005))
    return pk


def synflood(t, victim="192.168.1.50", n=800):
    pk = []
    for i in range(n):
        src = f"{random.randint(1, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"
        sp = random.randint(1024, 65535)
        tt = t + i * 0.0005
        pk.append(stamp(eth(IP(src=src, dst=victim) /
                            TCP(sport=sp, dport=80, flags="S", seq=random.randint(0, 2**31))), tt))
        if i % 3 == 0:   # serwer odpowiada na część, klient nigdy nie potwierdza
            pk.append(stamp(eth(IP(src=victim, dst=src) /
                                TCP(sport=80, dport=sp, flags="SA", seq=1, ack=1)), tt + 0.0001))
    return pk


def amplification(t, victim="192.168.1.77", reflector="198.51.100.53"):
    pk = []
    sp = 33333
    for i in range(60):
        tt = t + i * 0.01
        pk.append(stamp(eth(IP(src=victim, dst=reflector) / UDP(sport=sp, dport=53) /
                            DNS(rd=1, qd=DNSQR(qname="big.example", qtype=255))), tt))
        for k in range(3):
            pk.append(stamp(eth(IP(src=reflector, dst=victim) / UDP(sport=53, dport=sp) /
                                Raw(bytes(1400))), tt + 0.002 + k * 0.0002))
    return pk


def udp_stream(t, dur=3.0, pps=2500):
    pk = []
    n = int(dur * pps)
    for i in range(n):
        pk.append(stamp(eth(IP(src="192.168.1.30", dst="192.168.1.31") /
                            UDP(sport=5004, dport=5004) / Raw(bytes(160))), t + i / pps))
    return pk


def write(path, pkts):
    pkts.sort(key=lambda p: float(p.time))
    wrpcap(path, pkts)
    print(f"{path}: {len(pkts)} pakietów")


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else "samples"
    os.makedirs(out, exist_ok=True)

    write(f"{out}/normal.pcap", normal_traffic(T0, 120))
    write(f"{out}/portscan.pcap", normal_traffic(T0, 20, rate=1) + portscan(T0 + 5))
    write(f"{out}/synflood.pcap", normal_traffic(T0, 30, rate=1) + synflood(T0 + 10))
    write(f"{out}/amplification.pcap", normal_traffic(T0, 20, rate=1) + amplification(T0 + 5))

    mixed = normal_traffic(T0, 300, rate=1.5)
    mixed += portscan(T0 + 60)
    mixed += synflood(T0 + 150, n=400)
    mixed += amplification(T0 + 200)
    mixed += udp_stream(T0 + 240)
    s, _ = tcp_session("192.168.1.15", 51000, "203.0.113.10", 443, T0 + 100, rtt=0.06,
                       segs=80, loss=0.15)
    mixed += s
    s, _ = tcp_session("192.168.1.16", 51001, "192.168.1.200", 445, T0 + 110, segs=40,
                       zero_window=5)
    mixed += s
    s, _ = tcp_session("2001:db8::10", 52000, "2001:db8::443", 443, T0 + 120, v6=True, segs=20)
    mixed += s
    s, _ = tcp_session("192.168.1.17", 51002, "192.168.1.250", 23, T0 + 130, segs=3)
    mixed += s
    s, _ = tcp_session("10.10.0.5", 51003, "10.10.0.6", 8080, T0 + 140, vlan=100, segs=10,
                       close="rst")
    mixed += s
    s, _ = tcp_session("192.168.1.18", 51004, "198.51.100.200", 443, T0 + 160, rtt=1.8, segs=2)
    mixed += s
    write(f"{out}/mixed.pcap", mixed)


if __name__ == "__main__":
    main()
