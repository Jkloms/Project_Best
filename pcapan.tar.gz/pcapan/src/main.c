/*
 * main.c - interfejs wiersza poleceń i sterowanie analizą
 *
 * Analiza jest dwuprzebiegowa:
 *   1) szybki odczyt samych znaczników czasu -> zakres czasu zapisu,
 *      z którego wynika rozmiar szeregu czasowego (bez realokacji
 *      i bez założenia, że pliki są podane chronologicznie),
 *   2) pełne dekodowanie i agregacja.
 */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <getopt.h>
#include <sys/stat.h>
#include <pcap/pcap.h>
#include "pcapan.h"

static void usage(const char *prog)
{
    fprintf(stderr,
        "pcapan %s - analiza komunikacji TCP/UDP z plików pcap/pcapng\n\n"
        "Użycie: %s [opcje] plik.pcap [plik2.pcap ...]\n\n"
        "  -o, --output DIR        katalog wyjściowy (domyślnie: raport)\n"
        "  -i, --interval SEK      przedział szeregu czasowego (domyślnie: auto)\n"
        "  -n, --top N             liczba pozycji w rankingach (domyślnie: 10)\n"
        "  -f, --filter BPF        filtr BPF, np. \"host 10.0.0.1 and port 53\"\n"
        "  -q, --quiet             bez podsumowania na stdout\n"
        "      --no-pdf            tylko PNG i CSV\n"
        "Progi detekcji:\n"
        "      --scan-ports N      (15)   --scan-hosts N   (15)\n"
        "      --synflood N        (100)  --rst-ratio X    (0.30)\n"
        "      --retrans X         (0.05) --spike-sigma X  (6)\n"
        "      --amp-factor X      (10)   --udp-pps X      (1000)\n"
        "  -h, --help\n", PCAPAN_VERSION, prog);
}

static int mkdir_p(const char *path)
{
    char tmp[1024];
    snprintf(tmp, sizeof tmp, "%s", path);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = 0;
            if (mkdir(tmp, 0755) && errno != EEXIST) return -1;
            *p = '/';
        }
    }
    if (mkdir(tmp, 0755) && errno != EEXIST) return -1;
    return 0;
}

static pcap_t *open_file(const char *path, const char *filter, char *err)
{
    pcap_t *pc = pcap_open_offline_with_tstamp_precision(path, PCAP_TSTAMP_PRECISION_NANO, err);
    if (!pc) return NULL;
    if (filter) {
        struct bpf_program prog;
        if (pcap_compile(pc, &prog, filter, 1, PCAP_NETMASK_UNKNOWN) < 0 ||
            pcap_setfilter(pc, &prog) < 0) {
            snprintf(err, PCAP_ERRBUF_SIZE, "filtr BPF: %s", pcap_geterr(pc));
            pcap_close(pc);
            return NULL;
        }
        pcap_freecode(&prog);
    }
    return pc;
}

static inline double ts_of(const struct pcap_pkthdr *h)
{
    return (double)h->ts.tv_sec + (double)h->ts.tv_usec / 1e9;   /* precyzja NANO */
}

int main(int argc, char **argv)
{
    const char *outdir = "raport", *filter = NULL;
    double interval = 0;
    int topn = 10, quiet = 0, no_pdf = 0;
    thresholds_t th;
    thresholds_default(&th);

    enum { O_SCANP = 256, O_SCANH, O_SYN, O_RST, O_RTX, O_SPIKE, O_AMP, O_UDPPPS, O_NOPDF };
    static const struct option lo[] = {
        { "output", 1, 0, 'o' }, { "interval", 1, 0, 'i' }, { "top", 1, 0, 'n' },
        { "filter", 1, 0, 'f' }, { "quiet", 0, 0, 'q' }, { "help", 0, 0, 'h' },
        { "no-pdf", 0, 0, O_NOPDF },
        { "scan-ports", 1, 0, O_SCANP }, { "scan-hosts", 1, 0, O_SCANH },
        { "synflood", 1, 0, O_SYN }, { "rst-ratio", 1, 0, O_RST }, { "retrans", 1, 0, O_RTX },
        { "spike-sigma", 1, 0, O_SPIKE }, { "amp-factor", 1, 0, O_AMP },
        { "udp-pps", 1, 0, O_UDPPPS }, { 0, 0, 0, 0 }
    };
    int c;
    while ((c = getopt_long(argc, argv, "o:i:n:f:qh", lo, NULL)) != -1) {
        switch (c) {
        case 'o': outdir = optarg; break;
        case 'i': interval = atof(optarg); break;
        case 'n': topn = atoi(optarg); break;
        case 'f': filter = optarg; break;
        case 'q': quiet = 1; break;
        case O_NOPDF: no_pdf = 1; break;
        case O_SCANP: th.scan_ports = atoi(optarg); break;
        case O_SCANH: th.scan_hosts = atoi(optarg); break;
        case O_SYN: th.synflood_min = atoi(optarg); break;
        case O_RST: th.rst_ratio = atof(optarg); break;
        case O_RTX: th.retrans_ratio = atof(optarg); break;
        case O_SPIKE: th.spike_sigma = atof(optarg); break;
        case O_AMP: th.amp_factor = atof(optarg); break;
        case O_UDPPPS: th.udp_flood_pps = atof(optarg); break;
        case 'h': usage(argv[0]); return 0;
        default: usage(argv[0]); return 1;
        }
    }
    if (optind >= argc) { usage(argv[0]); return 1; }
    if (topn < 1) topn = 1;
    if (topn > MAX_TOPN) topn = MAX_TOPN;
    if (argc - optind > MAX_FILES) {
        fprintf(stderr, "pcapan: maksymalnie %d plików\n", MAX_FILES);
        return 1;
    }

    static analysis_t a;   /* duża struktura - poza stosem */
    memset(&a, 0, sizeof a);
    a.th = th;
    a.topn = topn;

    /* --- przebieg 1: zakres czasu --- */
    char err[PCAP_ERRBUF_SIZE];
    double tmin = 0, tmax = 0;
    int have_ts = 0, any_ok = 0;
    for (int i = optind; i < argc; i++) {
        input_file_t *in = &a.files[a.nfiles++];
        snprintf(in->name, sizeof in->name, "%s", argv[i]);
        pcap_t *pc = open_file(argv[i], filter, err);
        if (!pc) { fprintf(stderr, "pcapan: %s: %s\n", argv[i], err); continue; }
        in->dlt = pcap_datalink(pc);
        if (!dlt_supported(in->dlt)) {
            fprintf(stderr, "pcapan: %s: nieobsługiwany typ łącza %s (%d)\n", argv[i],
                    pcap_datalink_val_to_name(in->dlt) ? pcap_datalink_val_to_name(in->dlt) : "?",
                    in->dlt);
            pcap_close(pc);
            continue;
        }
        in->ok = 1;
        any_ok = 1;
        struct pcap_pkthdr *h;
        const u_char *data;
        int rc;
        while ((rc = pcap_next_ex(pc, &h, &data)) == 1) {
            double t = ts_of(h);
            if (!have_ts) { tmin = tmax = t; have_ts = 1; }
            if (t < tmin) tmin = t;
            if (t > tmax) tmax = t;
        }
        if (rc == -1) fprintf(stderr, "pcapan: %s: %s (plik obcięty?)\n", argv[i], pcap_geterr(pc));
        pcap_close(pc);
    }
    if (!any_ok) { fprintf(stderr, "pcapan: brak plików do analizy\n"); return 1; }
    if (!have_ts) { fprintf(stderr, "pcapan: pliki nie zawierają pakietów\n"); return 1; }

    if (analysis_init(&a, tmin, tmax, interval) < 0) {
        fprintf(stderr, "pcapan: zbyt mały przedział -i dla tak długiego zapisu\n");
        return 1;
    }

    /* --- przebieg 2: analiza --- */
    for (int i = 0; i < a.nfiles; i++) {
        input_file_t *in = &a.files[i];
        if (!in->ok) continue;
        pcap_t *pc = open_file(in->name, filter, err);
        if (!pc) { in->ok = 0; continue; }
        struct pcap_pkthdr *h;
        const u_char *data;
        while (pcap_next_ex(pc, &h, &data) == 1) {
            packet_t p;
            memset(&p, 0, sizeof p);
            p.ts = ts_of(h);
            p.caplen = h->caplen;
            p.wirelen = h->len;
            int rc = parse_packet(in->dlt, data, h->caplen, &p);
            analysis_add(&a, &p, rc);
            in->pkts++;
        }
        pcap_close(pc);
    }

    analysis_finalize(&a);
    detect_anomalies(&a);

    /* --- wyniki --- */
    if (mkdir_p(outdir) < 0) {
        fprintf(stderr, "pcapan: nie można utworzyć %s: %s\n", outdir, strerror(errno));
        return 1;
    }
    char path[1200];
    int fails = 0;
    for (int i = 0; i < CH__COUNT; i++) {
        snprintf(path, sizeof path, "%s/%s", outdir, chart_file[i]);
        if (chart_write_png(&a, (chart_id_t)i, path) < 0) {
            fprintf(stderr, "pcapan: błąd zapisu %s\n", path);
            fails++;
        }
    }
    snprintf(path, sizeof path, "%s/przeplywy.csv", outdir);
    if (report_write_csv(&a, path) < 0) { fprintf(stderr, "pcapan: błąd zapisu %s\n", path); fails++; }
    if (!no_pdf) {
        snprintf(path, sizeof path, "%s/raport.pdf", outdir);
        if (report_write_pdf(&a, path) < 0) { fprintf(stderr, "pcapan: błąd zapisu %s\n", path); fails++; }
    }

    if (!quiet) {
        report_print_summary(&a, stdout);
        printf("Wyniki zapisano w: %s/\n", outdir);
    }
    analysis_free(&a);
    /* kod wyjścia: 0 = OK, 3 = wykryto alarmy (przydatne w skryptach), 1 = błąd */
    if (fails) return 1;
    return a.sev_cnt[SEV_ALERT] ? 3 : 0;
}
