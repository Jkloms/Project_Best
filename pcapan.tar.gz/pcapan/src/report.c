/*
 * report.c - raport PDF (cairo-pdf), eksport CSV i podsumowanie na konsolę
 *
 * PDF składany jest ręcznie: prosty "kursor" pionowy, łamanie tekstu po
 * słowach i automatyczne łamanie stron. Wykresy wstawiane są wektorowo
 * tym samym kodem co PNG (chart_draw), więc w PDF są ostre przy każdym
 * powiększeniu.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <cairo.h>
#include <cairo-pdf.h>
#include "pcapan.h"

#define PAGE_W 595.28
#define PAGE_H 841.89
#define MARGIN 48.0
#define CONTENT_W (PAGE_W - 2 * MARGIN)
#define BOTTOM (PAGE_H - MARGIN - 14)

#define FONT "sans-serif"

typedef struct {
    cairo_surface_t *surf;
    cairo_t *cr;
    double y;
    int page;
} doc_t;

static void rgb(cairo_t *cr, unsigned c)
{
    cairo_set_source_rgb(cr, ((c >> 16) & 0xff) / 255.0, ((c >> 8) & 0xff) / 255.0,
                         (c & 0xff) / 255.0);
}

static void font(cairo_t *cr, double size, int bold)
{
    cairo_select_font_face(cr, FONT, CAIRO_FONT_SLANT_NORMAL,
                           bold ? CAIRO_FONT_WEIGHT_BOLD : CAIRO_FONT_WEIGHT_NORMAL);
    cairo_set_font_size(cr, size);
}

static double tw(cairo_t *cr, const char *s)
{
    cairo_text_extents_t e;
    cairo_text_extents(cr, s, &e);
    return e.x_advance;
}

static void put(cairo_t *cr, double x, double y, const char *s)
{
    cairo_move_to(cr, x, y);
    cairo_show_text(cr, s);
}

static void put_right(cairo_t *cr, double x, double y, const char *s)
{
    put(cr, x - tw(cr, s), y, s);
}

static void footer(doc_t *d)
{
    char b[32];
    rgb(d->cr, 0x8a8984);
    font(d->cr, 8, 0);
    put(d->cr, MARGIN, PAGE_H - MARGIN + 16, "pcapan " PCAPAN_VERSION " - analiza ruchu TCP/UDP");
    snprintf(b, sizeof b, "Strona %d", d->page);
    put_right(d->cr, PAGE_W - MARGIN, PAGE_H - MARGIN + 16, b);
}

static void new_page(doc_t *d)
{
    if (d->page > 0) {
        footer(d);
        cairo_show_page(d->cr);
    }
    d->page++;
    d->y = MARGIN;
}

static void need(doc_t *d, double h)
{
    if (d->y + h > BOTTOM) new_page(d);
}

/*
 * Łamanie tekstu na słowa. Gdy draw == 0, tylko mierzy wysokość - dzięki
 * temu przed narysowaniem bloku wiemy, czy zmieści się na stronie.
 */
static double wrap(cairo_t *cr, double x, double y, double width, const char *s,
                   double lh, int draw)
{
    char line[1600] = "", cand[1600];
    double h = 0;
    const char *p = s;
    while (*p) {
        const char *sp = strchr(p, ' ');
        size_t wl = sp ? (size_t)(sp - p) : strlen(p);
        char word[512];
        if (wl >= sizeof word) wl = sizeof word - 1;
        memcpy(word, p, wl); word[wl] = 0;
        /* cand = line + " " + word (z kontrolą długości) */
        size_t ll = strlen(line), k = ll;
        int overflow = ll + 1 + wl + 1 > sizeof cand;
        if (!overflow) {
            memcpy(cand, line, ll);
            if (ll) cand[k++] = ' ';
            memcpy(cand + k, word, wl + 1);
        }
        if (*line && (overflow || tw(cr, cand) > width)) {
            if (draw) put(cr, x, y + h, line);
            h += lh;
            snprintf(line, sizeof line, "%s", word);
        } else {
            snprintf(line, sizeof line, "%s", cand);
        }
        p += wl;
        while (*p == ' ') p++;
    }
    if (*line) { if (draw) put(cr, x, y + h, line); h += lh; }
    return h;
}

static void heading(doc_t *d, const char *s)
{
    need(d, 60);
    d->y += 10;
    rgb(d->cr, 0x0b0b0b);
    font(d->cr, 15, 1);
    put(d->cr, MARGIN, d->y + 14, s);
    d->y += 22;
    rgb(d->cr, 0xe6e5e0);
    cairo_set_line_width(d->cr, 1);
    cairo_move_to(d->cr, MARGIN, d->y + 0.5);
    cairo_line_to(d->cr, PAGE_W - MARGIN, d->y + 0.5);
    cairo_stroke(d->cr);
    d->y += 12;
}

static void para(doc_t *d, const char *s, double size, unsigned color)
{
    font(d->cr, size, 0);
    double lh = size * 1.45;
    double h = wrap(d->cr, MARGIN, 0, CONTENT_W, s, lh, 0);
    need(d, h);
    rgb(d->cr, color);
    wrap(d->cr, MARGIN, d->y + size, CONTENT_W, s, lh, 1);
    d->y += h + 6;
}

/* para klucz-wartość w dwóch kolumnach */
static void kv(doc_t *d, const char *k, const char *v)
{
    need(d, 16);
    font(d->cr, 9.5, 0);
    rgb(d->cr, 0x52514e);
    put(d->cr, MARGIN, d->y + 10, k);
    rgb(d->cr, 0x0b0b0b);
    font(d->cr, 9.5, 1);
    put(d->cr, MARGIN + 190, d->y + 10, v);
    d->y += 15;
}

/* --------------------------------------------------------------- tabela */

typedef struct { const char *title; double width; int right; } col_t;

static void fit(cairo_t *cr, char *s, double width)
{
    size_t n = strlen(s);
    if (tw(cr, s) <= width) return;
    while (n > 1) {
        n--;
        /* nie tniemy w środku znaku UTF-8 */
        while (n > 0 && ((unsigned char)s[n] & 0xC0) == 0x80) n--;
        s[n] = 0;
        char t[256];
        snprintf(t, sizeof t, "%s…", s);
        if (tw(cr, t) <= width) { strcpy(s, t); return; }
    }
}

static void table_header(doc_t *d, const col_t *c, int nc)
{
    double x = MARGIN;
    font(d->cr, 8, 1);
    rgb(d->cr, 0x52514e);
    for (int i = 0; i < nc; i++) {
        if (c[i].right) put_right(d->cr, x + c[i].width - 4, d->y + 10, c[i].title);
        else            put(d->cr, x, d->y + 10, c[i].title);
        x += c[i].width;
    }
    d->y += 15;
    rgb(d->cr, 0xb9b8b2);
    cairo_set_line_width(d->cr, 0.8);
    cairo_move_to(d->cr, MARGIN, d->y);
    cairo_line_to(d->cr, PAGE_W - MARGIN, d->y);
    cairo_stroke(d->cr);
    d->y += 3;
}

static void table_row(doc_t *d, const col_t *c, int nc, char cells[][128], int zebra)
{
    if (d->y + 14 > BOTTOM) { new_page(d); table_header(d, c, nc); }
    if (zebra) {
        rgb(d->cr, 0xf3f2ee);
        cairo_rectangle(d->cr, MARGIN, d->y, CONTENT_W, 14);
        cairo_fill(d->cr);
    }
    double x = MARGIN;
    font(d->cr, 8, 0);
    rgb(d->cr, 0x0b0b0b);
    for (int i = 0; i < nc; i++) {
        fit(d->cr, cells[i], c[i].width - 6);
        if (c[i].right) put_right(d->cr, x + c[i].width - 4, d->y + 10, cells[i]);
        else            put(d->cr, x, d->y + 10, cells[i]);
        x += c[i].width;
    }
    d->y += 14;
}

/* ------------------------------------------------------------- sekcje */

static void section_title(doc_t *d, const analysis_t *a)
{
    char b[128];
    time_t now = time(NULL);
    struct tm tm;
    localtime_r(&now, &tm);

    rgb(d->cr, 0x2a78d6);
    cairo_rectangle(d->cr, MARGIN, d->y, 40, 4);
    cairo_fill(d->cr);
    d->y += 30;
    rgb(d->cr, 0x0b0b0b);
    font(d->cr, 22, 1);
    put(d->cr, MARGIN, d->y, "Raport analizy ruchu TCP/UDP");
    d->y += 20;
    font(d->cr, 10, 0);
    rgb(d->cr, 0x52514e);
    strftime(b, sizeof b, "Wygenerowano %Y-%m-%d %H:%M", &tm);
    put(d->cr, MARGIN, d->y, b);
    d->y += 22;

    for (int i = 0; i < a->nfiles; i++) {
        char line[400];
        snprintf(line, sizeof line, "Plik: %s  (%llu pakietów%s)", a->files[i].name,
                 (unsigned long long)a->files[i].pkts, a->files[i].ok ? "" : ", BŁĄD ODCZYTU");
        para(d, line, 9, 0x52514e);
    }
}

static void section_summary(doc_t *d, const analysis_t *a)
{
    char v[128], b1[48], b2[48], b3[48];
    heading(d, "Podsumowanie");

    double span = a->last_ts - a->first_ts;
    kv(d, "Początek zapisu", fmt_time(a->first_ts, b1, sizeof b1));
    kv(d, "Koniec zapisu", fmt_time(a->last_ts, b1, sizeof b1));
    kv(d, "Czas trwania", fmt_duration(span, b1, sizeof b1));
    snprintf(v, sizeof v, "%llu  (%s)", (unsigned long long)a->total_pkts,
             fmt_bytes((double)a->total_bytes, b1, sizeof b1));
    kv(d, "Pakiety ogółem", v);
    if (span > 0) {
        snprintf(v, sizeof v, "%.1f kb/s, %.1f pakietów/s",
                 (double)a->total_bytes * 8 / span / 1000, (double)a->total_pkts / span);
        kv(d, "Średnie natężenie", v);
    }
    snprintf(v, sizeof v, "%llu pakietów, %s, %llu przepływów", (unsigned long long)a->tcp_pkts,
             fmt_bytes((double)a->tcp_bytes, b1, sizeof b1), (unsigned long long)a->tcp_flows);
    kv(d, "TCP", v);
    snprintf(v, sizeof v, "%llu pakietów, %s, %llu przepływów", (unsigned long long)a->udp_pkts,
             fmt_bytes((double)a->udp_bytes, b1, sizeof b1), (unsigned long long)a->udp_flows);
    kv(d, "UDP", v);
    snprintf(v, sizeof v, "IPv4: %llu, IPv6: %llu", (unsigned long long)a->ip4,
             (unsigned long long)a->ip6);
    kv(d, "Wersje IP (pakiety)", v);
    snprintf(v, sizeof v, "nie-IP: %llu, inne L4: %llu, fragmenty: %llu",
             (unsigned long long)a->non_ip, (unsigned long long)a->other_l4,
             (unsigned long long)a->fragments);
    kv(d, "Pominięte w analizie L4", v);
    snprintf(v, sizeof v, "obcięte: %llu, uszkodzone: %llu", (unsigned long long)a->truncated,
             (unsigned long long)a->malformed);
    kv(d, "Pakiety wadliwe", v);
    snprintf(v, sizeof v, "%zu", a->nhosts);
    kv(d, "Unikalne adresy IP", v);
    if (a->rtt_n) {
        snprintf(v, sizeof v, "mediana %s, p95 %s, max %s (n = %zu)",
                 fmt_duration(a->rtt_p50, b1, sizeof b1), fmt_duration(a->rtt_p95, b2, sizeof b2),
                 fmt_duration(a->rtt_max, b3, sizeof b3), a->rtt_n);
        kv(d, "RTT handshake TCP", v);
    }
    if (a->data_pkts_total) {
        snprintf(v, sizeof v, "%.2f%% (%llu z %llu segmentów z danymi)",
                 100.0 * a->retrans_total / a->data_pkts_total,
                 (unsigned long long)a->retrans_total, (unsigned long long)a->data_pkts_total);
        kv(d, "Retransmisje TCP", v);
    }
    snprintf(v, sizeof v, "%d alarmów, %d ostrzeżeń, %d informacji", a->sev_cnt[SEV_ALERT],
             a->sev_cnt[SEV_WARN], a->sev_cnt[SEV_INFO]);
    kv(d, "Nieprawidłowości", v);
}

static void section_anomalies(doc_t *d, const analysis_t *a)
{
    static const char *sev_name[3] = { "INFO", "OSTRZEŻENIE", "ALARM" };
    static const unsigned sev_col[3] = { 0x6b6a65, 0xb87700, 0xc62f2f };

    heading(d, "Wykryte nieprawidłowości");
    if (!a->nanoms) {
        para(d, "Nie wykryto nieprawidłowości przy bieżących progach detekcji.", 10, 0x0b0b0b);
        return;
    }
    for (size_t i = 0; i < a->nanoms; i++) {
        const anomaly_t *x = &a->anoms[i];
        font(d->cr, 9, 0);
        double th = wrap(d->cr, 0, 0, CONTENT_W - 12, x->text, 13, 0);
        need(d, th + 24);

        double y0 = d->y;
        /* pasek ważności po lewej + etykieta tekstowa (nie sam kolor) */
        rgb(d->cr, sev_col[x->sev]);
        cairo_rectangle(d->cr, MARGIN, y0 + 2, 3, th + 14);
        cairo_fill(d->cr);
        font(d->cr, 8, 1);
        put(d->cr, MARGIN + 12, y0 + 10, sev_name[x->sev]);
        double sx = MARGIN + 12 + tw(d->cr, sev_name[x->sev]) + 8;
        rgb(d->cr, 0x0b0b0b);
        font(d->cr, 9, 1);
        put(d->cr, sx, y0 + 10, x->category);

        rgb(d->cr, 0x333330);
        font(d->cr, 9, 0);
        wrap(d->cr, MARGIN + 12, y0 + 24, CONTENT_W - 12, x->text, 13, 1);
        d->y = y0 + th + 22;
    }
}

static void section_charts(doc_t *d, const analysis_t *a)
{
    const double cw = 720, ch = 400;          /* logiczny rozmiar wykresu */
    const double scale = CONTENT_W / cw;
    new_page(d);
    heading(d, "Wykresy");
    for (int i = 0; i < CH__COUNT; i++) {
        font(d->cr, 8.5, 0);
        double caph = wrap(d->cr, 0, 0, CONTENT_W, chart_caption[i], 12, 0);
        double h = ch * scale + caph + 22;
        need(d, h);
        cairo_save(d->cr);
        cairo_translate(d->cr, MARGIN, d->y);
        cairo_scale(d->cr, scale, scale);
        cairo_rectangle(d->cr, 0, 0, cw, ch);
        cairo_clip(d->cr);
        chart_draw(a, (chart_id_t)i, d->cr, cw, ch);
        cairo_restore(d->cr);
        /* ramka */
        rgb(d->cr, 0xe6e5e0);
        cairo_set_line_width(d->cr, 0.8);
        cairo_rectangle(d->cr, MARGIN, d->y, CONTENT_W, ch * scale);
        cairo_stroke(d->cr);
        d->y += ch * scale + 6;
        rgb(d->cr, 0x52514e);
        font(d->cr, 8.5, 0);
        wrap(d->cr, MARGIN, d->y + 9, CONTENT_W, chart_caption[i], 12, 1);
        d->y += caph + 16;
    }
}

static void section_top_flows(doc_t *d, const analysis_t *a)
{
    static const col_t c[] = {
        { "Klient", 118, 0 }, { "Serwer", 118, 0 }, { "Prot.", 28, 0 },
        { "Pakiety", 44, 1 }, { "Bajty", 50, 1 }, { "Czas", 46, 1 }, { "Stan", 95, 0 },
    };
    new_page(d);
    heading(d, "Największe przepływy");
    table_header(d, c, 7);
    size_t *idx = flows_sorted_by_bytes(a);
    size_t n = a->nflows < (size_t)a->topn * 2 ? a->nflows : (size_t)a->topn * 2;
    for (size_t i = 0; i < n; i++) {
        const flow_t *f = &a->flows[idx[i]];
        char cells[7][128];
        int ci = f->init;
        endpoint_str(f->key.family, ci == 0 ? f->key.a : f->key.b,
                     ci == 0 ? f->key.pa : f->key.pb, cells[0], 128);
        endpoint_str(f->key.family, ci == 0 ? f->key.b : f->key.a,
                     ci == 0 ? f->key.pb : f->key.pa, cells[1], 128);
        snprintf(cells[2], 128, "%s", f->key.proto == PROTO_TCP ? "TCP" : "UDP");
        snprintf(cells[3], 128, "%llu", (unsigned long long)(f->pkts[0] + f->pkts[1]));
        fmt_bytes((double)(f->bytes[0] + f->bytes[1]), cells[4], 128);
        fmt_duration(f->last - f->first, cells[5], 128);
        snprintf(cells[6], 128, "%s", conn_class_name[f->cls]);
        table_row(d, c, 7, cells, (int)(i & 1));
    }
    free(idx);
}

static void section_top_hosts(doc_t *d, const analysis_t *a)
{
    static const col_t c[] = {
        { "Adres IP", 170, 0 }, { "Wysłane", 62, 1 }, { "Odebrane", 62, 1 },
        { "Pakiety", 60, 1 }, { "Poł. wych.", 72, 1 }, { "Poł. przych.", 73, 1 },
    };
    heading(d, "Najaktywniejsze hosty");
    table_header(d, c, 6);
    size_t *idx = hosts_sorted_by_bytes(a);
    size_t n = a->nhosts < (size_t)a->topn * 2 ? a->nhosts : (size_t)a->topn * 2;
    for (size_t i = 0; i < n; i++) {
        const host_t *h = &a->hosts[idx[i]];
        char cells[6][128];
        addr_str(h->family, h->addr, cells[0], 128);
        fmt_bytes((double)h->tx_bytes, cells[1], 128);
        fmt_bytes((double)h->rx_bytes, cells[2], 128);
        snprintf(cells[3], 128, "%llu", (unsigned long long)(h->tx_pkts + h->rx_pkts));
        snprintf(cells[4], 128, "%u", h->flows_out);
        snprintf(cells[5], 128, "%u", h->flows_in);
        table_row(d, c, 6, cells, (int)(i & 1));
    }
    free(idx);
}

static void section_method(doc_t *d, const analysis_t *a)
{
    char b[600];
    heading(d, "Metodologia");
    para(d, "Przepływ to dwukierunkowa wymiana pakietów o tej samej 5-krotce (adresy, porty, "
            "protokół). Stroną inicjującą jest nadawca pierwszego SYN (TCP) lub pierwszego "
            "pakietu (UDP); gdy zapis zaczyna się w trakcie połączenia, klientem jest strona "
            "z wyższym, efemerycznym portem.", 9, 0x333330);
    para(d, "Stany TCP wynikają z obserwowanego handshake: SYN bez odpowiedzi, SYN zakończony "
            "RST (port zamknięty), SYN/ACK bez trzeciego ACK (półotwarte), zestawione i zamknięte "
            "przez FIN lub RST. Retransmisją jest segment z danymi, który nie przesuwa najwyższego "
            "widzianego numeru sekwencyjnego w danym kierunku (porównanie modulo 2^32).", 9, 0x333330);
    snprintf(b, sizeof b,
             "Progi detekcji: skanowanie pionowe >= %d portów, poziome >= %d hostów (liczone "
             "tylko z nieudanych prób); SYN flood >= %d półotwartych połączeń do jednej usługi; "
             "retransmisje > %.0f%% przy >= %d segmentach; resety > %.0f%% połączeń; wzmocnienie "
             "UDP >= %.0fx przy >= %llu B odpowiedzi; skok ruchu > mediana + %.0f x MAD.",
             a->th.scan_ports, a->th.scan_hosts, a->th.synflood_min, a->th.retrans_ratio * 100,
             a->th.retrans_min_pkts, a->th.rst_ratio * 100, a->th.amp_factor,
             (unsigned long long)a->th.amp_min_bytes, a->th.spike_sigma);
    para(d, b, 9, 0x333330);
    para(d, "Ograniczenia: analiza z jednego punktu przechwytywania nie odróżnia retransmisji od "
            "zmiany kolejności pakietów; RTT handshake mierzy opóźnienie między punktem "
            "przechwytywania a serwerem; ruch szyfrowany analizowany jest wyłącznie na podstawie "
            "nagłówków.", 9, 0x333330);
}

int report_write_pdf(const analysis_t *a, const char *path)
{
    doc_t d = { 0 };
    d.surf = cairo_pdf_surface_create(path, PAGE_W, PAGE_H);
    if (cairo_surface_status(d.surf) != CAIRO_STATUS_SUCCESS) return -1;
    cairo_pdf_surface_set_metadata(d.surf, CAIRO_PDF_METADATA_TITLE, "Raport analizy ruchu TCP/UDP");
    cairo_pdf_surface_set_metadata(d.surf, CAIRO_PDF_METADATA_CREATOR, "pcapan " PCAPAN_VERSION);
    d.cr = cairo_create(d.surf);
    new_page(&d);

    section_title(&d, a);
    section_summary(&d, a);
    section_anomalies(&d, a);
    section_charts(&d, a);
    section_top_flows(&d, a);
    section_top_hosts(&d, a);
    section_method(&d, a);

    footer(&d);
    cairo_show_page(d.cr);
    cairo_status_t st = cairo_status(d.cr);
    cairo_destroy(d.cr);
    cairo_surface_finish(d.surf);
    cairo_surface_destroy(d.surf);
    return st == CAIRO_STATUS_SUCCESS ? 0 : -1;
}

/* ------------------------------------------------------------------ CSV */

int report_write_csv(const analysis_t *a, const char *path)
{
    FILE *f = fopen(path, "w");
    if (!f) return -1;
    fprintf(f, "proto,client,client_port,server,server_port,start,duration_s,"
               "pkts_c2s,pkts_s2c,bytes_c2s,bytes_s2c,state,rtt_ms,retrans,zero_window\n");
    for (size_t i = 0; i < a->nflows; i++) {
        const flow_t *fl = &a->flows[i];
        int c = fl->init, s = 1 - c;
        char ca[64], sa[64];
        addr_str(fl->key.family, c == 0 ? fl->key.a : fl->key.b, ca, sizeof ca);
        addr_str(fl->key.family, c == 0 ? fl->key.b : fl->key.a, sa, sizeof sa);
        fprintf(f, "%s,%s,%u,%s,%u,%.6f,%.6f,%llu,%llu,%llu,%llu,\"%s\",",
                fl->key.proto == PROTO_TCP ? "TCP" : "UDP", ca,
                c == 0 ? fl->key.pa : fl->key.pb, sa, c == 0 ? fl->key.pb : fl->key.pa,
                fl->first, fl->last - fl->first,
                (unsigned long long)fl->pkts[c], (unsigned long long)fl->pkts[s],
                (unsigned long long)fl->bytes[c], (unsigned long long)fl->bytes[s],
                conn_class_name[fl->cls]);
        if (fl->rtt >= 0) fprintf(f, "%.3f", fl->rtt * 1000);
        fprintf(f, ",%u,%u\n", fl->retrans[0] + fl->retrans[1], fl->zero_win);
    }
    fclose(f);
    return 0;
}

/* ------------------------------------------------------------- konsola */

void report_print_summary(const analysis_t *a, FILE *o)
{
    static const char *sev[3] = { "INFO ", "UWAGA", "ALARM" };
    char b1[48], b2[48];
    fprintf(o, "Pakiety: %llu (%s), czas: %s\n", (unsigned long long)a->total_pkts,
            fmt_bytes((double)a->total_bytes, b1, sizeof b1),
            fmt_duration(a->last_ts - a->first_ts, b2, sizeof b2));
    fprintf(o, "TCP: %llu pakietów / %llu przepływów, UDP: %llu pakietów / %llu przepływów, "
               "hosty: %zu\n",
            (unsigned long long)a->tcp_pkts, (unsigned long long)a->tcp_flows,
            (unsigned long long)a->udp_pkts, (unsigned long long)a->udp_flows, a->nhosts);
    fprintf(o, "Nieprawidłowości: %d alarmów, %d ostrzeżeń, %d informacji\n",
            a->sev_cnt[SEV_ALERT], a->sev_cnt[SEV_WARN], a->sev_cnt[SEV_INFO]);
    for (size_t i = 0; i < a->nanoms; i++)
        fprintf(o, "  [%s] %s: %s\n", sev[a->anoms[i].sev], a->anoms[i].category, a->anoms[i].text);
}
