/*
 * analysis.c - agregacja pakietów w statystyki, przepływy i hosty
 *
 * Przepływ jest dwukierunkowy: pakiety A->B i B->A trafiają do tego samego
 * rekordu, bo klucz jest kanonizowany (mniejszy koniec zawsze jako "a").
 * Dzięki temu można analizować handshake, RTT i retransmisje w obu stronach.
 *
 * Tablice haszujące: łańcuchowanie po indeksach w tablicy dynamicznej
 * (a nie po wskaźnikach), więc realloc() tablicy rekordów nie unieważnia
 * łańcuchów, a rekordy da się później łatwo sortować i iterować.
 */
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "pcapan.h"

const char *conn_class_name[CC__COUNT] = {
    "zakończone (FIN)", "otwarte", "przerwane (RST)", "odrzucone (RST)",
    "półotwarte", "bez odpowiedzi", "od środka", "UDP dwukier.", "UDP jednokier."
};

/* FNV-1a */
static uint64_t hash_bytes(const void *p, size_t n)
{
    const uint8_t *b = p;
    uint64_t h = 1469598103934665603ULL;
    for (size_t i = 0; i < n; i++) { h ^= b[i]; h *= 1099511628211ULL; }
    return h;
}

int analysis_init(analysis_t *a, double first_ts, double last_ts, double interval)
{
    a->first_ts = first_ts;
    a->last_ts = last_ts;
    double span = last_ts - first_ts;
    if (span < 0) span = 0;

    /* automatyczny dobór przedziału: ~300 próbek, zaokrąglone do 1-2-5 */
    if (interval <= 0) {
        double raw = span / 300.0;
        static const double steps[] = { 0.001, 0.002, 0.005, 0.01, 0.02, 0.05, 0.1, 0.2, 0.5,
                                        1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 1800, 3600 };
        interval = steps[sizeof steps / sizeof steps[0] - 1];
        for (size_t i = 0; i < sizeof steps / sizeof steps[0]; i++)
            if (steps[i] >= raw) { interval = steps[i]; break; }
    }
    a->interval = interval;
    a->nbuckets = (size_t)(span / interval) + 1;
    if (a->nbuckets > 2000000) return -1;
    for (int i = 0; i < 2; i++) {
        a->tl_bytes[i] = xcalloc(a->nbuckets, sizeof(double));
        a->tl_pkts[i]  = xcalloc(a->nbuckets, sizeof(double));
        a->port_bytes[i] = xcalloc(65536, sizeof(uint64_t));
        a->port_flows[i] = xcalloc(65536, sizeof(uint32_t));
    }
    a->flow_nb = 1 << 14;
    a->flow_head = xmalloc(a->flow_nb * sizeof(int32_t));
    memset(a->flow_head, 0xFF, a->flow_nb * sizeof(int32_t));
    a->host_nb = 1 << 12;
    a->host_head = xmalloc(a->host_nb * sizeof(int32_t));
    memset(a->host_head, 0xFF, a->host_nb * sizeof(int32_t));
    return 0;
}

/* ---------------------------------------------------------------- hosty */

static void host_rehash(analysis_t *a)
{
    a->host_nb *= 2;
    a->host_head = xrealloc(a->host_head, a->host_nb * sizeof(int32_t));
    memset(a->host_head, 0xFF, a->host_nb * sizeof(int32_t));
    for (size_t i = 0; i < a->nhosts; i++) {
        host_t *h = &a->hosts[i];
        size_t b = hash_bytes(h->addr, 16) ^ h->family;
        b &= a->host_nb - 1;
        h->next = a->host_head[b];
        a->host_head[b] = (int32_t)i;
    }
}

static host_t *host_get(analysis_t *a, uint8_t family, const uint8_t *addr, int create)
{
    size_t b = (hash_bytes(addr, 16) ^ family) & (a->host_nb - 1);
    for (int32_t i = a->host_head[b]; i >= 0; i = a->hosts[i].next)
        if (a->hosts[i].family == family && !memcmp(a->hosts[i].addr, addr, 16))
            return &a->hosts[i];
    if (!create) return NULL;

    if (a->nhosts == a->hosts_cap) {
        a->hosts_cap = a->hosts_cap ? a->hosts_cap * 2 : 1024;
        a->hosts = xrealloc(a->hosts, a->hosts_cap * sizeof(host_t));
    }
    host_t *h = &a->hosts[a->nhosts];
    memset(h, 0, sizeof *h);
    h->family = family;
    memcpy(h->addr, addr, 16);
    h->next = a->host_head[b];
    a->host_head[b] = (int32_t)a->nhosts;
    a->nhosts++;
    if (a->nhosts > a->host_nb * 2) host_rehash(a);
    return &a->hosts[a->nhosts - 1];
}

host_t *host_find(analysis_t *a, uint8_t family, const uint8_t *addr)
{
    return host_get(a, family, addr, 0);
}

/* ------------------------------------------------------------ przepływy */

static void make_key(const packet_t *p, flow_key_t *k, int *dir)
{
    int c = memcmp(p->src, p->dst, 16);
    if (c == 0) c = (p->sport > p->dport) - (p->sport < p->dport);
    memset(k, 0, sizeof *k);
    k->family = p->family;
    k->proto = p->proto;
    if (c <= 0) {
        memcpy(k->a, p->src, 16); k->pa = p->sport;
        memcpy(k->b, p->dst, 16); k->pb = p->dport;
        *dir = 0;
    } else {
        memcpy(k->a, p->dst, 16); k->pa = p->dport;
        memcpy(k->b, p->src, 16); k->pb = p->sport;
        *dir = 1;
    }
}

static void flow_rehash(analysis_t *a)
{
    a->flow_nb *= 2;
    a->flow_head = xrealloc(a->flow_head, a->flow_nb * sizeof(int32_t));
    memset(a->flow_head, 0xFF, a->flow_nb * sizeof(int32_t));
    for (size_t i = 0; i < a->nflows; i++) {
        flow_t *f = &a->flows[i];
        size_t b = hash_bytes(&f->key, sizeof f->key) & (a->flow_nb - 1);
        f->next = a->flow_head[b];
        a->flow_head[b] = (int32_t)i;
    }
}

static flow_t *flow_get(analysis_t *a, const flow_key_t *k, int *created)
{
    size_t b = hash_bytes(k, sizeof *k) & (a->flow_nb - 1);
    for (int32_t i = a->flow_head[b]; i >= 0; i = a->flows[i].next)
        if (!memcmp(&a->flows[i].key, k, sizeof *k)) { *created = 0; return &a->flows[i]; }

    if (a->nflows == a->flows_cap) {
        a->flows_cap = a->flows_cap ? a->flows_cap * 2 : 4096;
        a->flows = xrealloc(a->flows, a->flows_cap * sizeof(flow_t));
    }
    flow_t *f = &a->flows[a->nflows];
    memset(f, 0, sizeof *f);
    f->key = *k;
    f->rtt = -1;
    f->next = a->flow_head[b];
    a->flow_head[b] = (int32_t)a->nflows;
    a->nflows++;
    *created = 1;
    if (a->nflows > a->flow_nb * 2) {
        flow_rehash(a);
    }
    return &a->flows[a->nflows - 1];
}

/* Porównanie numerów sekwencyjnych modulo 2^32 (RFC 1982). */
static inline int32_t seq_diff(uint32_t x, uint32_t y) { return (int32_t)(x - y); }

static void tcp_update(flow_t *f, const packet_t *p, int d)
{
    uint8_t fl = p->tcp_flags;

    if ((fl & TH_SYN) && !(fl & TH_ACK)) {
        f->seen_syn = 1;
        f->syn_count++;
        if (f->syn_ts == 0) f->syn_ts = p->ts;
    } else if ((fl & TH_SYN) && (fl & TH_ACK)) {
        if (!f->seen_synack && f->syn_ts > 0 && f->rtt < 0)
            f->rtt = p->ts - f->syn_ts;
        f->seen_synack = 1;
    } else if ((fl & TH_ACK) && f->seen_synack && !f->established && d == f->init
               && !(fl & TH_RST)) {
        f->established = 1;          /* trzeci krok handshake */
    }
    if (fl & TH_FIN) f->seen_fin[d] = 1;
    if (fl & TH_RST) { if (!f->seen_rst) f->rst_dir = (uint8_t)d; f->seen_rst = 1; }
    if ((fl & TH_ACK) && p->win == 0 && !(fl & (TH_RST | TH_SYN | TH_FIN)))
        f->zero_win++;

    /* Retransmisje: segment z danymi, który nie wychodzi poza najwyższy
     * dotychczas widziany koniec danych w tym kierunku, to powtórzenie
     * (albo pakiet poza kolejnością - z perspektywy jednego punktu
     * przechwytywania nie da się tego rozróżnić bez dodatkowej heurystyki). */
    uint32_t len = p->payload + ((fl & TH_SYN) ? 1u : 0u) + ((fl & TH_FIN) ? 1u : 0u);
    if (len > 0 && !(fl & TH_RST)) {
        uint32_t end = p->seq + len;
        if (f->seq_valid[d] && seq_diff(end, f->next_seq[d]) <= 0) {
            if (p->payload > 0) f->retrans[d]++;
        } else {
            f->next_seq[d] = end;
            f->seq_valid[d] = 1;
        }
        if (p->payload > 0) f->data_pkts[d]++;
    }
}

void analysis_add(analysis_t *a, const packet_t *p, int rc)
{
    a->total_pkts++;
    a->total_bytes += p->wirelen;

    if (rc == PARSE_NOT_IP) { a->non_ip++; return; }
    if (rc == PARSE_TRUNC)  { a->truncated++; return; }
    if (rc == PARSE_BAD)    { a->malformed++; return; }

    if (p->family == 4) a->ip4++; else a->ip6++;
    if (p->fragment) { a->fragments++; return; }
    if (p->proto != PROTO_TCP && p->proto != PROTO_UDP) { a->other_l4++; return; }
    if (!p->l4_ok) { a->truncated++; return; }

    int pi = p->proto == PROTO_TCP ? 0 : 1;
    if (pi == 0) { a->tcp_pkts++; a->tcp_bytes += p->wirelen; a->tcp_payload += p->payload; }
    else         { a->udp_pkts++; a->udp_bytes += p->wirelen; a->udp_payload += p->payload; }

    /* szereg czasowy */
    double rel = p->ts - a->first_ts;
    size_t bk = rel <= 0 ? 0 : (size_t)(rel / a->interval);
    if (bk >= a->nbuckets) bk = a->nbuckets - 1;
    a->tl_bytes[pi][bk] += p->wirelen;
    a->tl_pkts[pi][bk] += 1;

    /* histogram rozmiarów */
    size_t sb = p->wirelen / 100;
    if (sb >= SIZE_BINS) sb = SIZE_BINS - 1;
    a->size_hist[sb]++;

    /* flagi TCP */
    if (pi == 0) {
        uint8_t fl = p->tcp_flags;
        for (int i = 0; i < 8; i++) if (fl & (1 << i)) a->flag_cnt[i]++;
        if ((fl & (TH_SYN | TH_ACK)) == (TH_SYN | TH_ACK)) a->synack_cnt++;
        if (fl == 0) a->null_scan++;
        else if ((fl & (TH_FIN | TH_PSH | TH_URG)) == (TH_FIN | TH_PSH | TH_URG) && !(fl & TH_ACK))
            a->xmas_scan++;
        if ((fl & (TH_SYN | TH_FIN)) == (TH_SYN | TH_FIN)) a->synfin++;
    }

    /* hosty */
    host_t *hs = host_get(a, p->family, p->src, 1);
    hs->tx_bytes += p->wirelen; hs->tx_pkts++;
    host_t *hd = host_get(a, p->family, p->dst, 1);
    hd->rx_bytes += p->wirelen; hd->rx_pkts++;

    /* przepływ */
    flow_key_t k;
    int d, created;
    make_key(p, &k, &d);
    flow_t *f = flow_get(a, &k, &created);
    if (created) {
        f->first = p->ts;
        if (pi == 0) {
            uint8_t fl = p->tcp_flags;
            if ((fl & TH_SYN) && !(fl & TH_ACK))      f->init = d;
            else if ((fl & TH_SYN) && (fl & TH_ACK))  f->init = 1 - d;
            else {
                /* zapis od środka połączenia: zakładamy, że klientem jest
                 * strona z wyższym (efemerycznym) portem */
                uint16_t my = p->sport, other = p->dport;
                f->init = (my >= other) ? d : 1 - d;
            }
        } else {
            f->init = d;
        }
    }
    if (p->ts < f->first) f->first = p->ts;
    if (p->ts > f->last) f->last = p->ts;
    f->pkts[d]++;
    f->bytes[d] += p->wirelen;
    f->payload[d] += p->payload;
    if (pi == 0) tcp_update(f, p, d);
}

/* --------------------------------------------------------- finalizacja */

static conn_class_t classify(const flow_t *f)
{
    if (f->key.proto == PROTO_UDP)
        return (f->pkts[0] && f->pkts[1]) ? CC_UDP_BIDIR : CC_UDP_ONEWAY;
    if (!f->seen_syn && !f->seen_synack) return CC_MIDSTREAM;
    if (f->established || (f->seen_synack && f->pkts[0] + f->pkts[1] > 3 &&
                           f->data_pkts[0] + f->data_pkts[1] > 0)) {
        if (f->seen_rst) return CC_RESET;
        if (f->seen_fin[0] || f->seen_fin[1]) return CC_COMPLETE;
        return CC_OPEN;
    }
    if (f->seen_rst && f->rst_dir != f->init) return CC_REJECTED;
    if (f->seen_synack) return CC_HALFOPEN;
    if (f->seen_rst) return CC_REJECTED;
    return CC_UNANSWERED;
}

static int cmp_double(const void *x, const void *y)
{
    double a = *(const double *)x, b = *(const double *)y;
    return (a > b) - (a < b);
}

static double percentile(const double *v, size_t n, double q)
{
    if (!n) return 0;
    double pos = q * (double)(n - 1);
    size_t i = (size_t)pos;
    if (i + 1 >= n) return v[n - 1];
    return v[i] + (pos - (double)i) * (v[i + 1] - v[i]);
}

void analysis_finalize(analysis_t *a)
{
    a->rtts = xmalloc((a->nflows ? a->nflows : 1) * sizeof(double));
    for (size_t i = 0; i < a->nflows; i++) {
        flow_t *f = &a->flows[i];
        f->cls = classify(f);
        a->class_cnt[f->cls]++;

        int pi = f->key.proto == PROTO_TCP ? 0 : 1;
        if (pi == 0) a->tcp_flows++; else a->udp_flows++;

        /* port usługi = port strony odpowiadającej */
        uint16_t sport = f->init == 0 ? f->key.pb : f->key.pa;
        a->port_bytes[pi][sport] += f->bytes[0] + f->bytes[1];
        a->port_flows[pi][sport]++;

        const uint8_t *ia = f->init == 0 ? f->key.a : f->key.b;
        const uint8_t *ra = f->init == 0 ? f->key.b : f->key.a;
        host_t *h = host_get(a, f->key.family, ia, 0);
        if (h) h->flows_out++;
        h = host_get(a, f->key.family, ra, 0);
        if (h) h->flows_in++;

        if (pi == 0) {
            a->retrans_total += f->retrans[0] + f->retrans[1];
            a->data_pkts_total += f->data_pkts[0] + f->data_pkts[1];
            if (f->rtt >= 0) a->rtts[a->rtt_n++] = f->rtt;
        }
    }
    qsort(a->rtts, a->rtt_n, sizeof(double), cmp_double);
    a->rtt_p50 = percentile(a->rtts, a->rtt_n, 0.50);
    a->rtt_p95 = percentile(a->rtts, a->rtt_n, 0.95);
    a->rtt_max = a->rtt_n ? a->rtts[a->rtt_n - 1] : 0;
}

/* ------------------------------------------------------------ sortowanie */

static const analysis_t *g_sort_ctx;

static int cmp_flow_bytes(const void *x, const void *y)
{
    const flow_t *f = &g_sort_ctx->flows[*(const size_t *)x];
    const flow_t *g = &g_sort_ctx->flows[*(const size_t *)y];
    uint64_t a = f->bytes[0] + f->bytes[1], b = g->bytes[0] + g->bytes[1];
    return (a < b) - (a > b);
}

static int cmp_host_bytes(const void *x, const void *y)
{
    const host_t *f = &g_sort_ctx->hosts[*(const size_t *)x];
    const host_t *g = &g_sort_ctx->hosts[*(const size_t *)y];
    uint64_t a = f->tx_bytes + f->rx_bytes, b = g->tx_bytes + g->rx_bytes;
    return (a < b) - (a > b);
}

size_t *flows_sorted_by_bytes(const analysis_t *a)
{
    size_t *idx = xmalloc((a->nflows ? a->nflows : 1) * sizeof(size_t));
    for (size_t i = 0; i < a->nflows; i++) idx[i] = i;
    g_sort_ctx = a;
    qsort(idx, a->nflows, sizeof(size_t), cmp_flow_bytes);
    return idx;
}

size_t *hosts_sorted_by_bytes(const analysis_t *a)
{
    size_t *idx = xmalloc((a->nhosts ? a->nhosts : 1) * sizeof(size_t));
    for (size_t i = 0; i < a->nhosts; i++) idx[i] = i;
    g_sort_ctx = a;
    qsort(idx, a->nhosts, sizeof(size_t), cmp_host_bytes);
    return idx;
}

void analysis_free(analysis_t *a)
{
    for (int i = 0; i < 2; i++) {
        free(a->tl_bytes[i]); free(a->tl_pkts[i]);
        free(a->port_bytes[i]); free(a->port_flows[i]);
    }
    free(a->flows); free(a->flow_head);
    free(a->hosts); free(a->host_head);
    free(a->rtts); free(a->anoms);
}
