/*
 * pcapan - analizator ruchu TCP/UDP z plików pcap/pcapng
 *
 * Wspólne typy i interfejsy modułów. Przepływ danych:
 *
 *   main.c ──> pcap (libpcap) ──> parser.c ──> analysis.c ──> anomaly.c
 *                                  (pakiet)    (przepływy,     (detektory)
 *                                               hosty, porty,
 *                                               szereg czasowy)
 *                                                    │
 *                           chart.c (cairo) <────────┤
 *                           report.c (cairo-pdf) <───┘
 */
#ifndef PCAPAN_H
#define PCAPAN_H

#include <stdint.h>
#include <stddef.h>
#include <stdio.h>

#define PCAPAN_VERSION "1.0"

/* ------------------------------------------------------------------ */
/* Pakiet po zdekodowaniu (wyjście parsera)                            */
/* ------------------------------------------------------------------ */

#define TH_FIN 0x01
#define TH_SYN 0x02
#define TH_RST 0x04
#define TH_PSH 0x08
#define TH_ACK 0x10
#define TH_URG 0x20
#define TH_ECE 0x40
#define TH_CWR 0x80

#define PROTO_TCP 6
#define PROTO_UDP 17

typedef struct {
    double   ts;          /* znacznik czasu [s] */
    uint32_t caplen;      /* bajty zapisane w pliku */
    uint32_t wirelen;     /* bajty na łączu (oryginalna długość ramki) */
    uint8_t  family;      /* 4, 6; 0 = nie-IP */
    uint8_t  proto;       /* numer protokołu L4 */
    uint8_t  src[16], dst[16];   /* IPv4 zajmuje pierwsze 4 bajty, reszta = 0 */
    uint16_t sport, dport;
    uint8_t  ttl;         /* TTL / hop limit */
    uint8_t  tcp_flags;
    uint32_t seq, ack;
    uint16_t win;
    uint32_t payload;     /* długość danych L4 wyliczona z nagłówków IP */
    uint8_t  l4_ok;       /* nagłówek TCP/UDP był w całości dostępny */
    uint8_t  fragment;    /* niepierwszy fragment IP (brak nagłówka L4) */
} packet_t;

enum { PARSE_OK = 0, PARSE_NOT_IP, PARSE_TRUNC, PARSE_BAD };

int  dlt_supported(int dlt);
int  parse_packet(int dlt, const uint8_t *data, uint32_t caplen, packet_t *p);

/* ------------------------------------------------------------------ */
/* Przepływy (dwukierunkowe, klucz = 5-krotka w postaci kanonicznej)   */
/* ------------------------------------------------------------------ */

typedef struct {
    uint8_t  family, proto;
    uint8_t  a[16], b[16];   /* a <= b (porządek leksykograficzny adres:port) */
    uint16_t pa, pb;
} flow_key_t;

/* Klasyfikacja połączenia po zakończeniu analizy */
typedef enum {
    CC_COMPLETE = 0,  /* TCP: handshake + zamknięcie FIN */
    CC_OPEN,          /* TCP: zestawione, bez zamknięcia do końca zapisu */
    CC_RESET,         /* TCP: zestawione, zakończone RST */
    CC_REJECTED,      /* TCP: SYN -> RST (port zamknięty) */
    CC_HALFOPEN,      /* TCP: SYN -> SYN/ACK, brak końcowego ACK */
    CC_UNANSWERED,    /* TCP: SYN bez odpowiedzi */
    CC_MIDSTREAM,     /* TCP: zapis zaczął się w trakcie połączenia */
    CC_UDP_BIDIR,     /* UDP: ruch w obu kierunkach */
    CC_UDP_ONEWAY,    /* UDP: ruch tylko w jedną stronę */
    CC__COUNT
} conn_class_t;

extern const char *conn_class_name[CC__COUNT];

typedef struct {
    flow_key_t key;
    int32_t  next;            /* łańcuch w tablicy haszującej */
    double   first, last;
    int      init;            /* 0 = stroną inicjującą jest a, 1 = b */
    uint64_t pkts[2], bytes[2], payload[2];   /* [0] a->b, [1] b->a */
    /* TCP */
    uint8_t  seen_syn, seen_synack, established, seen_rst, rst_dir;
    uint8_t  seen_fin[2];
    uint32_t syn_count;       /* liczba SYN (powtórzenia = retransmisje SYN) */
    uint32_t next_seq[2];
    uint8_t  seq_valid[2];
    uint32_t retrans[2], data_pkts[2];
    uint32_t zero_win;
    double   syn_ts;
    double   rtt;             /* SYN -> SYN/ACK [s], <0 gdy nieznane */
    conn_class_t cls;
} flow_t;

/* ------------------------------------------------------------------ */
/* Hosty                                                               */
/* ------------------------------------------------------------------ */

typedef struct {
    uint8_t  family;
    uint8_t  addr[16];
    int32_t  next;
    uint64_t tx_bytes, rx_bytes, tx_pkts, rx_pkts;
    uint32_t flows_out, flows_in;
} host_t;

/* ------------------------------------------------------------------ */
/* Anomalie                                                            */
/* ------------------------------------------------------------------ */

typedef enum { SEV_INFO = 0, SEV_WARN, SEV_ALERT } severity_t;

typedef struct {
    severity_t sev;
    char category[48];
    char text[320];
} anomaly_t;

typedef struct {
    int    scan_ports;        /* min. różnych portów na parę src->dst */
    int    scan_hosts;        /* min. różnych hostów na parę src:port */
    int    synflood_min;      /* min. półotwartych połączeń do jednej usługi */
    double rst_ratio;         /* próg udziału połączeń zakończonych RST */
    double retrans_ratio;     /* próg retransmisji (na przepływ) */
    int    retrans_min_pkts;  /* min. pakietów z danymi, by oceniać przepływ */
    double spike_sigma;       /* próg skoku ruchu w odchyleniach std. */
    double amp_factor;        /* współczynnik wzmocnienia UDP */
    uint64_t amp_min_bytes;   /* min. bajtów odpowiedzi dla wzmocnienia */
    double udp_flood_pps;     /* próg pakietów/s dla jednego strumienia UDP */
    double slow_rtt;          /* próg wolnego handshake [s] */
} thresholds_t;

void thresholds_default(thresholds_t *t);

/* ------------------------------------------------------------------ */
/* Stan całej analizy                                                  */
/* ------------------------------------------------------------------ */

#define MAX_TOPN 50
#define SIZE_BINS 16         /* histogram rozmiarów: 0-99, ..., 1400-1499, >=1500 */
#define MAX_FILES 64

typedef struct {
    char     name[256];
    int      dlt;
    uint64_t pkts;
    int      ok;
} input_file_t;

typedef struct {
    /* pliki wejściowe */
    input_file_t files[MAX_FILES];
    int      nfiles;

    /* liczniki globalne */
    uint64_t total_pkts, total_bytes;
    uint64_t ip4, ip6, non_ip, other_l4, truncated, malformed, fragments;
    uint64_t tcp_pkts, tcp_bytes, udp_pkts, udp_bytes;
    uint64_t tcp_payload, udp_payload;
    uint64_t flag_cnt[8];         /* liczba pakietów z danym bitem flagi */
    uint64_t synack_cnt;
    uint64_t null_scan, xmas_scan, synfin;   /* niepoprawne kombinacje flag */
    uint64_t size_hist[SIZE_BINS];

    double   first_ts, last_ts;

    /* szereg czasowy: [0]=TCP, [1]=UDP */
    double   interval;
    size_t   nbuckets;
    double  *tl_bytes[2];
    double  *tl_pkts[2];

    /* przepływy */
    flow_t  *flows;
    size_t   nflows, flows_cap;
    int32_t *flow_head;
    size_t   flow_nb;

    /* hosty */
    host_t  *hosts;
    size_t   nhosts, hosts_cap;
    int32_t *host_head;
    size_t   host_nb;

    /* porty usług (port strony odpowiadającej): [0]=TCP, [1]=UDP */
    uint64_t *port_bytes[2];
    uint32_t *port_flows[2];

    /* wyniki po finalizacji */
    uint64_t class_cnt[CC__COUNT];
    uint64_t tcp_flows, udp_flows;
    uint64_t retrans_total, data_pkts_total;
    double   rtt_p50, rtt_p95, rtt_max;
    size_t   rtt_n;
    double  *rtts;               /* posortowane RTT [s] */

    /* anomalie */
    anomaly_t *anoms;
    size_t   nanoms, anoms_cap;
    int      sev_cnt[3];

    thresholds_t th;
    int      topn;
} analysis_t;

/* analysis.c */
int   analysis_init(analysis_t *a, double first_ts, double last_ts, double interval);
void  analysis_add(analysis_t *a, const packet_t *p, int parse_rc);
void  analysis_finalize(analysis_t *a);
void  analysis_free(analysis_t *a);
host_t *host_find(analysis_t *a, uint8_t family, const uint8_t *addr);
/* zwraca tablicę indeksów posortowaną malejąco (wywołujący zwalnia) */
size_t *flows_sorted_by_bytes(const analysis_t *a);
size_t *hosts_sorted_by_bytes(const analysis_t *a);

/* anomaly.c */
void  detect_anomalies(analysis_t *a);
void  anomaly_add(analysis_t *a, severity_t s, const char *cat, const char *fmt, ...)
        __attribute__((format(printf, 4, 5)));

/* chart.c */
typedef enum {
    CH_THROUGHPUT = 0,
    CH_PACKET_RATE,
    CH_PROTO_SHARE,
    CH_SIZE_HIST,
    CH_TOP_HOSTS,
    CH_TOP_PORTS,
    CH_TCP_FLAGS,
    CH_CONN_STATES,
    CH_RTT_HIST,
    CH_FLOW_DURATION,
    CH__COUNT
} chart_id_t;

typedef struct _cairo cairo_t;
extern const char *chart_file[CH__COUNT];
extern const char *chart_title[CH__COUNT];
extern const char *chart_caption[CH__COUNT];
void  chart_draw(const analysis_t *a, chart_id_t id, cairo_t *cr, double w, double h);
int   chart_write_png(const analysis_t *a, chart_id_t id, const char *path);

/* report.c */
int   report_write_pdf(const analysis_t *a, const char *path);
int   report_write_csv(const analysis_t *a, const char *path);
void  report_print_summary(const analysis_t *a, FILE *out);

/* util.c */
const char *addr_str(uint8_t family, const uint8_t *addr, char *buf, size_t n);
const char *endpoint_str(uint8_t family, const uint8_t *addr, uint16_t port, char *buf, size_t n);
const char *fmt_bytes(double v, char *buf, size_t n);
const char *fmt_count(double v, char *buf, size_t n);
const char *fmt_time(double ts, char *buf, size_t n);
const char *fmt_duration(double s, char *buf, size_t n);
const char *service_name(int proto, uint16_t port);
void *xmalloc(size_t n);
void *xcalloc(size_t n, size_t sz);
void *xrealloc(void *p, size_t n);

#endif
