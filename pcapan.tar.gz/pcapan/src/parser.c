/*
 * parser.c - dekodowanie ramek: warstwa łącza -> IPv4/IPv6 -> TCP/UDP
 *
 * Parser jest bezstanowy i nie alokuje pamięci. Każde odczytanie pola jest
 * poprzedzone sprawdzeniem długości, bo pliki pcap mogą zawierać ramki
 * obcięte (snaplen) lub celowo uszkodzone.
 */
#include <string.h>
#include <pcap/pcap.h>
#include "pcapan.h"

static inline uint16_t rd16(const uint8_t *p) { return (uint16_t)((p[0] << 8) | p[1]); }
static inline uint32_t rd32(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3];
}

#ifndef DLT_LINUX_SLL2
#define DLT_LINUX_SLL2 276
#endif
#ifndef DLT_IPV4
#define DLT_IPV4 228
#endif
#ifndef DLT_IPV6
#define DLT_IPV6 229
#endif

int dlt_supported(int dlt)
{
    switch (dlt) {
    case DLT_EN10MB: case DLT_LINUX_SLL: case DLT_LINUX_SLL2:
    case DLT_RAW: case DLT_IPV4: case DLT_IPV6:
    case DLT_NULL: case DLT_LOOP:
        return 1;
    }
    return 0;
}

#define ETH_IPV4 0x0800
#define ETH_IPV6 0x86DD

/* Zwraca przesunięcie początku nagłówka IP oraz EtherType (0x0800 / 0x86DD),
 * albo -1 gdy ramka nie niesie IP. */
static int link_layer(int dlt, const uint8_t *d, uint32_t len, uint16_t *etype)
{
    uint32_t off;
    switch (dlt) {
    case DLT_EN10MB:
        if (len < 14) return -2;
        off = 12;
        *etype = rd16(d + off);
        /* znaczniki VLAN 802.1Q / 802.1ad (QinQ), możliwe zagnieżdżenie */
        while (*etype == 0x8100 || *etype == 0x88A8 || *etype == 0x9100) {
            off += 4;
            if (len < off + 2) return -2;
            *etype = rd16(d + off);
        }
        return (int)(off + 2);
    case DLT_LINUX_SLL:            /* "Linux cooked capture" v1, 16 B */
        if (len < 16) return -2;
        *etype = rd16(d + 14);
        return 16;
    case DLT_LINUX_SLL2:           /* v2, 20 B, protokół na początku */
        if (len < 20) return -2;
        *etype = rd16(d);
        return 20;
    case DLT_NULL:
    case DLT_LOOP: {               /* BSD loopback: 4 B rodziny adresów */
        if (len < 4) return -2;
        /* DLT_NULL jest w kolejności bajtów hosta, DLT_LOOP sieciowej -
         * sprawdzamy oba końce słowa. */
        uint8_t fam = d[0] ? d[0] : d[3];
        if (fam == 2) *etype = ETH_IPV4;
        else if (fam == 24 || fam == 28 || fam == 30) *etype = ETH_IPV6;
        else return -1;
        return 4;
    }
    case DLT_RAW: case DLT_IPV4: case DLT_IPV6:
        if (len < 1) return -2;
        *etype = ((d[0] >> 4) == 6) ? ETH_IPV6 : ETH_IPV4;
        return 0;
    }
    return -1;
}

static int parse_l4(const uint8_t *d, uint32_t cap, uint32_t l4len, packet_t *p)
{
    if (p->proto == PROTO_TCP) {
        if (cap < 20) return PARSE_TRUNC;
        uint32_t doff = (uint32_t)(d[12] >> 4) * 4;
        if (doff < 20) return PARSE_BAD;
        p->sport = rd16(d);
        p->dport = rd16(d + 2);
        p->seq = rd32(d + 4);
        p->ack = rd32(d + 8);
        p->tcp_flags = d[13];
        p->win = rd16(d + 14);
        p->payload = l4len > doff ? l4len - doff : 0;
        p->l4_ok = 1;
    } else if (p->proto == PROTO_UDP) {
        if (cap < 8) return PARSE_TRUNC;
        p->sport = rd16(d);
        p->dport = rd16(d + 2);
        p->payload = l4len > 8 ? l4len - 8 : 0;
        p->l4_ok = 1;
    }
    return PARSE_OK;
}

static int parse_ipv4(const uint8_t *d, uint32_t cap, packet_t *p)
{
    if (cap < 20) return PARSE_TRUNC;
    if ((d[0] >> 4) != 4) return PARSE_BAD;
    uint32_t ihl = (uint32_t)(d[0] & 0x0F) * 4;
    if (ihl < 20) return PARSE_BAD;
    if (cap < ihl) return PARSE_TRUNC;

    uint32_t total = rd16(d + 2);
    /* total == 0 zdarza się przy przechwyceniu z TSO - bierzemy długość z ramki */
    if (total == 0) total = cap;
    if (total < ihl) return PARSE_BAD;

    p->family = 4;
    p->ttl = d[8];
    p->proto = d[9];
    memcpy(p->src, d + 12, 4);
    memcpy(p->dst, d + 16, 4);

    uint16_t frag = rd16(d + 6);
    if (frag & 0x1FFF) {         /* niezerowy offset: brak nagłówka L4 */
        p->fragment = 1;
        return PARSE_OK;
    }
    uint32_t l4cap = cap - ihl;
    return parse_l4(d + ihl, l4cap, total - ihl, p);
}

static int parse_ipv6(const uint8_t *d, uint32_t cap, packet_t *p)
{
    if (cap < 40) return PARSE_TRUNC;
    if ((d[0] >> 4) != 6) return PARSE_BAD;

    uint32_t plen = rd16(d + 4);
    uint8_t nh = d[6];
    p->family = 6;
    p->ttl = d[7];
    memcpy(p->src, d + 8, 16);
    memcpy(p->dst, d + 24, 16);

    uint32_t off = 40;
    if (plen == 0) plen = cap - 40;   /* jumbogram / TSO */

    /* przechodzimy po nagłówkach rozszerzeń */
    for (int guard = 0; guard < 16; guard++) {
        if (nh == 0 || nh == 43 || nh == 60) {          /* hop-by-hop, routing, dest-opts */
            if (cap < off + 2) return PARSE_TRUNC;
            uint32_t hl = ((uint32_t)d[off + 1] + 1) * 8;
            nh = d[off];
            off += hl;
        } else if (nh == 51) {                           /* AH */
            if (cap < off + 2) return PARSE_TRUNC;
            uint32_t hl = ((uint32_t)d[off + 1] + 2) * 4;
            nh = d[off];
            off += hl;
        } else if (nh == 44) {                           /* fragment */
            if (cap < off + 8) return PARSE_TRUNC;
            uint16_t fo = rd16(d + off + 2) >> 3;
            nh = d[off];
            off += 8;
            if (fo != 0) { p->proto = nh; p->fragment = 1; return PARSE_OK; }
        } else {
            break;
        }
    }
    p->proto = nh;
    if (off > cap) return PARSE_TRUNC;
    uint32_t ext = off - 40;
    uint32_t l4len = plen > ext ? plen - ext : 0;
    return parse_l4(d + off, cap - off, l4len, p);
}

int parse_packet(int dlt, const uint8_t *data, uint32_t caplen, packet_t *p)
{
    uint16_t etype = 0;
    int off = link_layer(dlt, data, caplen, &etype);
    if (off == -2) return PARSE_TRUNC;
    if (off < 0) return PARSE_NOT_IP;

    const uint8_t *ip = data + off;
    uint32_t cap = caplen - (uint32_t)off;
    if (etype == ETH_IPV4) return parse_ipv4(ip, cap, p);
    if (etype == ETH_IPV6) return parse_ipv6(ip, cap, p);
    return PARSE_NOT_IP;
}
