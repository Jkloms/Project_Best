/*
 * anomaly.c - heurystyczne wykrywanie nieprawidłowości
 *
 * Każdy detektor działa na zagregowanych przepływach (a nie na pojedynczych
 * pakietach), więc jest odporny na kolejność pakietów i działa w jednym
 * przebiegu po tablicy przepływów. Progi są w thresholds_t i można je
 * zmieniać z linii poleceń.
 *
 * Wykrywane zjawiska:
 *   - skanowanie portów pionowe (1 źródło -> 1 cel, wiele portów)
 *   - skanowanie poziome       (1 źródło -> wiele celów, ten sam port)
 *   - SYN flood                (wiele półotwartych połączeń do 1 usługi)
 *   - pakiety z niepoprawnymi flagami (NULL / XMAS / SYN+FIN)
 *   - wysoki udział połączeń przerwanych RST
 *   - retransmisje TCP (globalnie i per przepływ)
 *   - zero window (odbiorca nie nadąża)
 *   - nagłe skoki natężenia ruchu (mediana + MAD)
 *   - wzmocnienie UDP (odpowiedź >> zapytanie)
 *   - intensywne strumienie UDP
 *   - wolne zestawianie połączeń (RTT handshake)
 *   - nieszyfrowane / podejrzane usługi
 *   - pakiety uszkodzone lub obcięte
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include <arpa/inet.h>
#include "pcapan.h"

void thresholds_default(thresholds_t *t)
{
    t->scan_ports = 15;
    t->scan_hosts = 15;
    t->synflood_min = 100;
    t->rst_ratio = 0.30;
    t->retrans_ratio = 0.05;
    t->retrans_min_pkts = 20;
    t->spike_sigma = 6.0;
    t->amp_factor = 10.0;
    t->amp_min_bytes = 50000;
    t->udp_flood_pps = 1000.0;
    t->slow_rtt = 1.0;
}

void anomaly_add(analysis_t *a, severity_t s, const char *cat, const char *fmt, ...)
{
    if (a->nanoms == a->anoms_cap) {
        a->anoms_cap = a->anoms_cap ? a->anoms_cap * 2 : 32;
        a->anoms = xrealloc(a->anoms, a->anoms_cap * sizeof(anomaly_t));
    }
    anomaly_t *x = &a->anoms[a->nanoms++];
    x->sev = s;
    snprintf(x->category, sizeof x->category, "%s", cat);
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(x->text, sizeof x->text, fmt, ap);
    va_end(ap);
    a->sev_cnt[s]++;
}

/* ----------------------------------------- nieudane próby połączenia */

typedef struct {
    uint8_t  family, proto;
    uint8_t  src[16], dst[16];
    uint16_t dport;
    double   ts;
} attempt_t;

static int cmp_src_dst_port(const void *x, const void *y)
{
    const attempt_t *a = x, *b = y;
    int c;
    if ((c = a->family - b->family)) return c;
    if ((c = memcmp(a->src, b->src, 16))) return c;
    if ((c = memcmp(a->dst, b->dst, 16))) return c;
    if ((c = a->proto - b->proto)) return c;
    return (int)a->dport - (int)b->dport;
}

static int cmp_src_port_dst(const void *x, const void *y)
{
    const attempt_t *a = x, *b = y;
    int c;
    if ((c = a->family - b->family)) return c;
    if ((c = memcmp(a->src, b->src, 16))) return c;
    if ((c = a->proto - b->proto)) return c;
    if ((c = (int)a->dport - (int)b->dport)) return c;
    return memcmp(a->dst, b->dst, 16);
}

static int cmp_dst_port_src(const void *x, const void *y)
{
    const attempt_t *a = x, *b = y;
    int c;
    if ((c = a->family - b->family)) return c;
    if ((c = memcmp(a->dst, b->dst, 16))) return c;
    if ((c = a->proto - b->proto)) return c;
    if ((c = (int)a->dport - (int)b->dport)) return c;
    return memcmp(a->src, b->src, 16);
}

static const char *pname(int proto) { return proto == PROTO_TCP ? "TCP" : "UDP"; }

/*
 * Skanowanie wykrywamy po nieudanych próbach, nie po wszystkich połączeniach:
 * przeglądarka otwiera wiele połączeń, ale prawie wszystkie kończą się
 * sukcesem. Skaner trafia głównie w zamknięte porty (RST / brak odpowiedzi).
 * Po posortowaniu krotek liczenie unikalnych wartości to jeden liniowy
 * przebieg - O(n log n) bez dodatkowych struktur.
 */
static void detect_scans(analysis_t *a)
{
    attempt_t *v = xmalloc((a->nflows ? a->nflows : 1) * sizeof *v);
    size_t n = 0;
    for (size_t i = 0; i < a->nflows; i++) {
        const flow_t *f = &a->flows[i];
        if (f->cls != CC_UNANSWERED && f->cls != CC_REJECTED &&
            f->cls != CC_HALFOPEN && f->cls != CC_UDP_ONEWAY)
            continue;
        attempt_t *t = &v[n++];
        t->family = f->key.family;
        t->proto = f->key.proto;
        memcpy(t->src, f->init == 0 ? f->key.a : f->key.b, 16);
        memcpy(t->dst, f->init == 0 ? f->key.b : f->key.a, 16);
        t->dport = f->init == 0 ? f->key.pb : f->key.pa;
        t->ts = f->first;
    }
    char s1[64], s2[64], d1[32];
    int reported = 0;

    /* pionowe: (src, dst) -> liczba różnych portów */
    qsort(v, n, sizeof *v, cmp_src_dst_port);
    for (size_t i = 0; i < n;) {
        size_t j = i; int ports = 0; uint16_t lo = 65535, hi = 0;
        double t0 = v[i].ts, t1 = v[i].ts;
        while (j < n && v[j].family == v[i].family && v[j].proto == v[i].proto &&
               !memcmp(v[j].src, v[i].src, 16) && !memcmp(v[j].dst, v[i].dst, 16)) {
            if (j == i || v[j].dport != v[j - 1].dport) ports++;
            if (v[j].dport < lo) lo = v[j].dport;
            if (v[j].dport > hi) hi = v[j].dport;
            if (v[j].ts < t0) t0 = v[j].ts;
            if (v[j].ts > t1) t1 = v[j].ts;
            j++;
        }
        if (ports >= a->th.scan_ports && reported < 20) {
            anomaly_add(a, SEV_ALERT, "Skanowanie portów",
                        "%s sprawdził %d portów %s hosta %s (zakres %u-%u) w ciągu %s "
                        "bez nawiązania połączenia.",
                        addr_str(v[i].family, v[i].src, s1, sizeof s1), ports, pname(v[i].proto),
                        addr_str(v[i].family, v[i].dst, s2, sizeof s2), lo, hi,
                        fmt_duration(t1 - t0, d1, sizeof d1));
            reported++;
        }
        i = j;
    }

    /* poziome: (src, port) -> liczba różnych hostów */
    qsort(v, n, sizeof *v, cmp_src_port_dst);
    for (size_t i = 0; i < n;) {
        size_t j = i; int hosts = 0;
        while (j < n && v[j].family == v[i].family && v[j].proto == v[i].proto &&
               !memcmp(v[j].src, v[i].src, 16) && v[j].dport == v[i].dport) {
            if (j == i || memcmp(v[j].dst, v[j - 1].dst, 16)) hosts++;
            j++;
        }
        if (hosts >= a->th.scan_hosts && reported < 40) {
            anomaly_add(a, SEV_ALERT, "Skanowanie sieci",
                        "%s próbował połączyć się z portem %s/%u na %d różnych hostach "
                        "bez powodzenia.",
                        addr_str(v[i].family, v[i].src, s1, sizeof s1), pname(v[i].proto),
                        v[i].dport, hosts);
            reported++;
        }
        i = j;
    }

    /* SYN flood: (dst, port) -> półotwarte/bez odpowiedzi TCP, liczba źródeł */
    qsort(v, n, sizeof *v, cmp_dst_port_src);
    for (size_t i = 0; i < n;) {
        size_t j = i; int cnt = 0, srcs = 0;
        double t0 = v[i].ts, t1 = v[i].ts;
        while (j < n && v[j].family == v[i].family && v[j].proto == v[i].proto &&
               !memcmp(v[j].dst, v[i].dst, 16) && v[j].dport == v[i].dport) {
            cnt++;
            if (j == i || memcmp(v[j].src, v[j - 1].src, 16)) srcs++;
            if (v[j].ts < t0) t0 = v[j].ts;
            if (v[j].ts > t1) t1 = v[j].ts;
            j++;
        }
        if (v[i].proto == PROTO_TCP && cnt >= a->th.synflood_min) {
            double rate = t1 > t0 ? cnt / (t1 - t0) : (double)cnt;
            anomaly_add(a, SEV_ALERT, "SYN flood",
                        "%d nieudanych prób połączenia z %s:%u od %d źródeł "
                        "(%.0f prób/s)%s.",
                        cnt, addr_str(v[i].family, v[i].dst, s1, sizeof s1), v[i].dport,
                        srcs, rate,
                        srcs > cnt / 2 ? " - wiele unikalnych źródeł sugeruje fałszowanie adresów"
                                       : "");
        }
        i = j;
    }
    free(v);
}

/* ------------------------------------------------- skoki natężenia */

static int cmp_d(const void *x, const void *y)
{
    double a = *(const double *)x, b = *(const double *)y;
    return (a > b) - (a < b);
}

/*
 * Mediana i MAD zamiast średniej i odchylenia standardowego: sam skok
 * zawyża średnią i odchylenie, przez co klasyczny z-score "chowa" właśnie
 * te wartości, których szukamy. Mediana/MAD są na to odporne.
 */
static void detect_spikes(analysis_t *a)
{
    /* Okno co najmniej 1 s: TCP z natury wysyła paczki segmentów w ciągu
     * milisekund, więc przy krótkich oknach każda sesja wyglądałaby na skok. */
    size_t k = a->interval >= 1.0 ? 1 : (size_t)ceil(1.0 / a->interval);
    double win = a->interval * (double)k;
    size_t n = (a->nbuckets + k - 1) / k;
    if (n < 10) return;
    double *v = xcalloc(n, sizeof(double)), *s = xmalloc(n * sizeof(double));
    for (size_t i = 0; i < a->nbuckets; i++) v[i / k] += a->tl_pkts[0][i] + a->tl_pkts[1][i];
    for (size_t i = 0; i < n; i++) v[i] /= win;          /* pakiety/s */
    memcpy(s, v, n * sizeof(double));
    qsort(s, n, sizeof(double), cmp_d);
    double med = s[n / 2];
    for (size_t i = 0; i < n; i++) s[i] = fabs(v[i] - med);
    qsort(s, n, sizeof(double), cmp_d);
    double sigma = 1.4826 * s[n / 2];
    if (sigma < 1) sigma = 1;
    double thr = med + a->th.spike_sigma * sigma;
    if (thr < 3 * med) thr = 3 * med;
    if (thr < 100) thr = 100;       /* poniżej 100 pkt/s nie ma czego zgłaszać */

    int episodes = 0;
    char t1[48], t2[48];
    for (size_t i = 0; i < n;) {
        if (v[i] <= thr) { i++; continue; }
        size_t j = i; double peak = 0;
        while (j < n && v[j] > thr) { if (v[j] > peak) peak = v[j]; j++; }
        if (episodes < 5) {
            char ratio[48] = "";
            if (med >= 1) snprintf(ratio, sizeof ratio, " (%.0fx typowego poziomu)", peak / med);
            anomaly_add(a, SEV_WARN, "Skok natężenia ruchu",
                        "%s - %s: szczyt %.0f pakietów/s przy medianie %.0f pakietów/s%s.",
                        fmt_time(a->first_ts + (double)i * win, t1, sizeof t1),
                        fmt_time(a->first_ts + (double)j * win, t2, sizeof t2),
                        peak, med, ratio);
        }
        episodes++;
        i = j;
    }
    if (episodes > 5)
        anomaly_add(a, SEV_INFO, "Skok natężenia ruchu",
                    "Pominięto %d kolejnych epizodów podwyższonego ruchu.", episodes - 5);
    free(v); free(s);
}

/* ---------------------------------------------------- per przepływ */

static void detect_flow_issues(analysis_t *a)
{
    char e1[80], e2[80], b1[32], b2[32];
    int rtx_rep = 0, zw_rep = 0, amp_rep = 0, flood_rep = 0, slow_rep = 0;
    uint64_t zw_flows = 0, slow_flows = 0;

    for (size_t i = 0; i < a->nflows; i++) {
        const flow_t *f = &a->flows[i];
        int ci = f->init, ri = 1 - f->init;
        const uint8_t *ca = ci == 0 ? f->key.a : f->key.b;
        const uint8_t *ra = ci == 0 ? f->key.b : f->key.a;
        uint16_t cp = ci == 0 ? f->key.pa : f->key.pb;
        uint16_t rp = ci == 0 ? f->key.pb : f->key.pa;
        double dur = f->last - f->first;

        if (f->key.proto == PROTO_TCP) {
            uint32_t data = f->data_pkts[0] + f->data_pkts[1];
            uint32_t rtx = f->retrans[0] + f->retrans[1];
            if (data >= (uint32_t)a->th.retrans_min_pkts &&
                (double)rtx / data > a->th.retrans_ratio && rtx_rep < 8) {
                anomaly_add(a, SEV_WARN, "Retransmisje TCP",
                            "%s -> %s: %u z %u segmentów z danymi powtórzonych (%.1f%%) - "
                            "możliwa utrata pakietów lub przeciążenie łącza.",
                            endpoint_str(f->key.family, ca, cp, e1, sizeof e1),
                            endpoint_str(f->key.family, ra, rp, e2, sizeof e2),
                            rtx, data, 100.0 * rtx / data);
                rtx_rep++;
            }
            if (f->zero_win > 0) {
                zw_flows++;
                if (zw_rep < 5) {
                    anomaly_add(a, SEV_WARN, "Zero window",
                                "%s <-> %s: %u ogłoszeń zerowego okna - odbiorca nie nadąża "
                                "z przetwarzaniem danych.",
                                endpoint_str(f->key.family, ca, cp, e1, sizeof e1),
                                endpoint_str(f->key.family, ra, rp, e2, sizeof e2),
                                f->zero_win);
                    zw_rep++;
                }
            }
            if (f->rtt > a->th.slow_rtt) {
                slow_flows++;
                if (slow_rep < 3) {
                    anomaly_add(a, SEV_INFO, "Wolny handshake",
                                "%s -> %s: SYN/ACK po %s (mediana w zapisie: %s).",
                                endpoint_str(f->key.family, ca, cp, e1, sizeof e1),
                                endpoint_str(f->key.family, ra, rp, e2, sizeof e2),
                                fmt_duration(f->rtt, b1, sizeof b1),
                                fmt_duration(a->rtt_p50, b2, sizeof b2));
                    slow_rep++;
                }
            }
        } else {
            /* Wzmocnienie: mała prośba, ogromna odpowiedź. Typowe dla ataków
             * odbiciowych przez DNS/NTP/memcached/SSDP ze sfałszowanym źródłem. */
            uint64_t req = f->bytes[ci], resp = f->bytes[ri];
            if (req > 0 && resp >= a->th.amp_min_bytes &&
                (double)resp / (double)req >= a->th.amp_factor && amp_rep < 8) {
                const char *svc = service_name(PROTO_UDP, rp);
                anomaly_add(a, SEV_ALERT, "Wzmocnienie UDP",
                            "%s (%s) odpowiedział %s na %s zapytań od %s - współczynnik %.0fx.",
                            endpoint_str(f->key.family, ra, rp, e1, sizeof e1),
                            svc ? svc : "nieznana usługa",
                            fmt_bytes((double)resp, b1, sizeof b1),
                            fmt_bytes((double)req, b2, sizeof b2),
                            endpoint_str(f->key.family, ca, cp, e2, sizeof e2),
                            (double)resp / (double)req);
                amp_rep++;
            }
            uint64_t pk = f->pkts[0] + f->pkts[1];
            if (dur >= 1.0 && pk / dur > a->th.udp_flood_pps && flood_rep < 5) {
                anomaly_add(a, SEV_WARN, "Intensywny strumień UDP",
                            "%s -> %s: %.0f pakietów/s przez %s (%s).",
                            endpoint_str(f->key.family, ca, cp, e1, sizeof e1),
                            endpoint_str(f->key.family, ra, rp, e2, sizeof e2),
                            pk / dur, fmt_duration(dur, b1, sizeof b1),
                            fmt_bytes((double)(f->bytes[0] + f->bytes[1]), b2, sizeof b2));
                flood_rep++;
            }
        }
    }
    if (zw_flows > (uint64_t)zw_rep)
        anomaly_add(a, SEV_INFO, "Zero window",
                    "Łącznie %llu przepływów z zerowym oknem.", (unsigned long long)zw_flows);
    if (slow_flows > (uint64_t)slow_rep)
        anomaly_add(a, SEV_INFO, "Wolny handshake",
                    "Łącznie %llu połączeń z RTT handshake > %.1f s.",
                    (unsigned long long)slow_flows, a->th.slow_rtt);
}

/* --------------------------------------------------------- globalne */

static void detect_global(analysis_t *a)
{
    char b1[32];

    if (a->null_scan || a->xmas_scan || a->synfin) {
        anomaly_add(a, SEV_ALERT, "Niepoprawne flagi TCP",
                    "Pakiety bez flag (NULL): %llu, FIN+PSH+URG (XMAS): %llu, SYN+FIN: %llu. "
                    "Takie kombinacje nie występują w poprawnym stosie TCP - typowe dla "
                    "skanowania (nmap -sN/-sX) lub prób omijania zapór.",
                    (unsigned long long)a->null_scan, (unsigned long long)a->xmas_scan,
                    (unsigned long long)a->synfin);
    }

    uint64_t tcp_conn = a->class_cnt[CC_COMPLETE] + a->class_cnt[CC_OPEN] +
                        a->class_cnt[CC_RESET] + a->class_cnt[CC_REJECTED] +
                        a->class_cnt[CC_HALFOPEN] + a->class_cnt[CC_UNANSWERED];
    uint64_t bad = a->class_cnt[CC_RESET] + a->class_cnt[CC_REJECTED];
    if (tcp_conn >= 20 && (double)bad / tcp_conn > a->th.rst_ratio) {
        anomaly_add(a, SEV_WARN, "Dużo resetów TCP",
                    "%.1f%% połączeń TCP (%llu z %llu) zakończyło się RST - "
                    "usługa odrzuca połączenia, zapora je ucina lub trwa skanowanie.",
                    100.0 * bad / tcp_conn, (unsigned long long)bad,
                    (unsigned long long)tcp_conn);
    }

    if (a->data_pkts_total >= 100) {
        double r = (double)a->retrans_total / a->data_pkts_total;
        if (r > 0.02)
            anomaly_add(a, r > 0.10 ? SEV_ALERT : SEV_WARN, "Retransmisje TCP",
                        "Globalny wskaźnik retransmisji %.2f%% (%llu z %llu segmentów). "
                        "W zdrowej sieci LAN zwykle < 1%%.",
                        100.0 * r, (unsigned long long)a->retrans_total,
                        (unsigned long long)a->data_pkts_total);
    }

    if (a->truncated || a->malformed) {
        anomaly_add(a, a->malformed ? SEV_WARN : SEV_INFO, "Uszkodzone pakiety",
                    "Obcięte: %llu, niepoprawne nagłówki: %llu. Obcięcie zwykle wynika z "
                    "małego snaplen; błędne nagłówki mogą oznaczać celowo spreparowany ruch.",
                    (unsigned long long)a->truncated, (unsigned long long)a->malformed);
    }

    if (a->fragments > 0 && a->fragments * 20 > a->ip4 + a->ip6) {
        anomaly_add(a, SEV_WARN, "Fragmentacja IP",
                    "%llu fragmentów IP (%.1f%% ruchu IP) - nietypowo dużo; fragmentacja "
                    "bywa używana do omijania IDS.",
                    (unsigned long long)a->fragments,
                    100.0 * a->fragments / (double)(a->ip4 + a->ip6));
    }

    /* usługi przesyłające dane jawnym tekstem / znane porty backdoorów */
    static const struct { int proto; uint16_t port; const char *why; } risky[] = {
        { 6, 21,   "FTP - hasła jawnym tekstem" },
        { 6, 23,   "Telnet - hasła jawnym tekstem" },
        { 6, 110,  "POP3 bez TLS" },
        { 6, 143,  "IMAP bez TLS" },
        { 6, 4444, "domyślny port Metasploit" },
        { 6, 6667, "IRC - częsty kanał C&C botnetów" },
        { 6, 31337, "klasyczny port backdoorów" },
        { 17, 69,  "TFTP bez uwierzytelniania" },
    };
    /* liczymy tylko przepływy, w których faktycznie płynęły dane - sama próba
     * połączenia (np. w trakcie skanowania) nie oznacza, że usługa działa */
    for (size_t i = 0; i < sizeof risky / sizeof risky[0]; i++) {
        uint32_t fl = 0;
        uint64_t bytes = 0;
        for (size_t j = 0; j < a->nflows; j++) {
            const flow_t *f = &a->flows[j];
            if (f->key.proto != risky[i].proto) continue;
            uint16_t sp = f->init == 0 ? f->key.pb : f->key.pa;
            if (sp != risky[i].port || f->payload[0] + f->payload[1] == 0) continue;
            if (f->cls == CC_UDP_ONEWAY || f->cls == CC_UNANSWERED || f->cls == CC_REJECTED)
                continue;
            fl++;
            bytes += f->bytes[0] + f->bytes[1];
        }
        if (fl)
            anomaly_add(a, risky[i].port >= 4444 ? SEV_WARN : SEV_INFO, "Ryzykowna usługa",
                        "Ruch na porcie %s/%u (%s): %u przepływów z danymi, %s.",
                        pname(risky[i].proto), risky[i].port, risky[i].why, fl,
                        fmt_bytes((double)bytes, b1, sizeof b1));
    }
}

static int cmp_anom(const void *x, const void *y)
{
    const anomaly_t *a = x, *b = y;
    return (int)b->sev - (int)a->sev;
}

void detect_anomalies(analysis_t *a)
{
    detect_global(a);
    detect_scans(a);
    detect_spikes(a);
    detect_flow_issues(a);
    /* stabilne sortowanie po ważności (insertion sort - lista jest krótka,
     * a qsort nie gwarantuje stabilności, więc kolejność w kategorii by się psuła) */
    for (size_t i = 1; i < a->nanoms; i++) {
        anomaly_t t = a->anoms[i];
        size_t j = i;
        while (j > 0 && cmp_anom(&a->anoms[j - 1], &t) > 0) { a->anoms[j] = a->anoms[j - 1]; j--; }
        a->anoms[j] = t;
    }
}
