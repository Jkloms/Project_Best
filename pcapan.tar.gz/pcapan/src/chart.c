/*
 * chart.c - wykresy rysowane biblioteką cairo
 *
 * Każdy wykres rysuje się na dowolnym cairo_t w logicznym układzie
 * współrzędnych w x h. Dzięki temu ten sam kod tworzy:
 *   - pliki PNG (cairo_image_surface, skalowanie x2 dla ostrości),
 *   - wektorowe wykresy wewnątrz raportu PDF (cairo_pdf_surface).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <cairo.h>
#include "pcapan.h"

/* paleta: jasna powierzchnia, tekst w odcieniach szarości, kolory serii
 * tylko na znacznikach danych */
#define C_SURFACE   0xfcfcfb
#define C_TEXT      0x0b0b0b
#define C_TEXT2     0x52514e
#define C_MUTED     0x8a8984
#define C_GRID      0xe6e5e0
#define C_AXIS      0xb9b8b2
#define C_S1        0x2a78d6   /* TCP / seria podstawowa */
#define C_S2        0xeb6834   /* UDP */

#define FONT "sans-serif"

const char *chart_file[CH__COUNT] = {
    "01_przepustowosc.png", "02_pakiety_na_sekunde.png", "03_udzial_protokolow.png",
    "04_rozmiary_pakietow.png", "05_top_hosty.png", "06_top_uslugi.png",
    "07_flagi_tcp.png", "08_stany_polaczen.png", "09_rtt_handshake.png",
    "10_czas_trwania_przeplywow.png",
};

const char *chart_title[CH__COUNT] = {
    "Przepustowość w czasie", "Pakiety na sekundę", "Udział TCP i UDP",
    "Rozkład rozmiarów pakietów", "Najaktywniejsze hosty", "Najaktywniejsze usługi",
    "Flagi TCP", "Stany połączeń", "RTT zestawiania połączeń TCP",
    "Czas trwania przepływów",
};

const char *chart_caption[CH__COUNT] = {
    "Natężenie ruchu w bitach na sekundę, osobno dla TCP i UDP. Pozwala wskazać okresy "
    "wzmożonej transmisji i porównać udział protokołów w czasie.",
    "Liczba pakietów na sekundę. Gwałtowne piki przy płaskiej przepustowości oznaczają "
    "wiele małych pakietów - typowe dla skanowania i ataków flood.",
    "Procentowy udział TCP i UDP w liczbie pakietów, bajtach i przepływach.",
    "Rozkład długości ramek. Ruch masowy skupia się przy MTU (~1500 B), "
    "potwierdzenia TCP i zapytania DNS - w najniższym przedziale.",
    "Hosty o największym wolumenie (wysłane + odebrane).",
    "Porty usług (port strony odpowiadającej) według wolumenu przesłanych danych.",
    "Liczba pakietów TCP z danym bitem flagi (skala logarytmiczna). Nadmiar SYN względem "
    "SYN/ACK lub duża liczba RST wskazuje na problemy z nawiązywaniem połączeń.",
    "Klasyfikacja przepływów na podstawie obserwowanego przebiegu handshake i zamknięcia.",
    "Czas między SYN a SYN/ACK widziany w punkcie przechwytywania. Przybliża opóźnienie "
    "sieci i obciążenie serwerów.",
    "Rozkład czasu życia przepływów TCP i UDP.",
};

/* ------------------------------------------------------------ prymitywy */

static void rgb(cairo_t *cr, unsigned c)
{
    cairo_set_source_rgb(cr, ((c >> 16) & 0xff) / 255.0, ((c >> 8) & 0xff) / 255.0,
                         (c & 0xff) / 255.0);
}

static void font(cairo_t *cr, double size, int bold)
{
    cairo_select_font_face(cr, FONT, CAIRO_FONT_SLANT_NORMAL,
                           bold ? CAIRO_FONT_WEIGHT_BOLD : CAIRO_FONT_WEIGHT_NORMAL);
    cairo_set_font_size(cr, size);
}

/* align: 0 = lewo, 0.5 = środek, 1 = prawo; valign analogicznie (0 = linia bazowa) */
static void text(cairo_t *cr, double x, double y, const char *s, double align, double valign)
{
    cairo_text_extents_t e;
    cairo_text_extents(cr, s, &e);
    cairo_move_to(cr, x - e.x_advance * align, y + e.height * valign);
    cairo_show_text(cr, s);
}

static double text_w(cairo_t *cr, const char *s)
{
    cairo_text_extents_t e;
    cairo_text_extents(cr, s, &e);
    return e.x_advance;
}

/* zaokrąglony prostokąt zaokrąglony tylko od strony wartości (koniec słupka) */
static void bar_path(cairo_t *cr, double x, double y, double w, double h, int horizontal)
{
    double r = 3;
    if (horizontal) { if (r > w) r = w; if (r > h / 2) r = h / 2; }
    else            { if (r > h) r = h; if (r > w / 2) r = w / 2; }
    if (r < 0.5) { cairo_rectangle(cr, x, y, w, h); return; }
    if (horizontal) {           /* zaokrąglony prawy koniec */
        cairo_move_to(cr, x, y);
        cairo_line_to(cr, x + w - r, y);
        cairo_arc(cr, x + w - r, y + r, r, -M_PI / 2, 0);
        cairo_line_to(cr, x + w, y + h - r);
        cairo_arc(cr, x + w - r, y + h - r, r, 0, M_PI / 2);
        cairo_line_to(cr, x, y + h);
    } else {                    /* zaokrąglona góra */
        cairo_move_to(cr, x, y + h);
        cairo_line_to(cr, x, y + r);
        cairo_arc(cr, x + r, y + r, r, M_PI, 1.5 * M_PI);
        cairo_line_to(cr, x + w - r, y);
        cairo_arc(cr, x + w - r, y + r, r, 1.5 * M_PI, 2 * M_PI);
        cairo_line_to(cr, x + w, y + h);
    }
    cairo_close_path(cr);
}

/* "ładny" krok osi: 1, 2, 2.5 lub 5 x 10^k */
static double nice_step(double range, int target)
{
    if (range <= 0) return 1;
    double raw = range / target;
    double mag = pow(10, floor(log10(raw)));
    double f = raw / mag;
    double s = f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10;
    return s * mag;
}

typedef const char *(*fmt_fn)(double, char *, size_t);

static const char *fmt_bits(double v, char *b, size_t n)
{
    const char *u[] = { "b/s", "kb/s", "Mb/s", "Gb/s", "Tb/s" };
    int i = 0;
    while (fabs(v) >= 1000 && i < 4) { v /= 1000; i++; }
    snprintf(b, n, v == floor(v) ? "%.0f %s" : "%.1f %s", v, u[i]);
    return b;
}

static const char *fmt_pct(double v, char *b, size_t n) { snprintf(b, n, "%.0f%%", v); return b; }

static const char *fmt_reltime(double s, char *b, size_t n)
{
    if (s < 1 && s > 0)   snprintf(b, n, "%.0f ms", s * 1000);
    else if (s < 120)     snprintf(b, n, "%.0f s", s);
    else if (s < 7200)    snprintf(b, n, "%.0f min", s / 60);
    else                  snprintf(b, n, "%.1f h", s / 3600);
    return b;
}

typedef struct { double x, y, w, h; } rect_t;

/* Tło, tytuł i podtytuł; zwraca obszar na wykres. */
static rect_t frame(cairo_t *cr, double w, double h, const char *title, const char *sub)
{
    rgb(cr, C_SURFACE);
    cairo_rectangle(cr, 0, 0, w, h);
    cairo_fill(cr);
    rgb(cr, C_TEXT);
    font(cr, 17, 1);
    text(cr, 24, 34, title, 0, 0);
    double top = 44;
    if (sub && *sub) {
        rgb(cr, C_TEXT2);
        font(cr, 12, 0);
        text(cr, 24, 56, sub, 0, 0);
        top = 66;
    }
    rect_t r = { 24, top + 14, w - 48, h - top - 14 - 20 };
    return r;
}

static void no_data(cairo_t *cr, rect_t r)
{
    rgb(cr, C_MUTED);
    font(cr, 14, 0);
    text(cr, r.x + r.w / 2, r.y + r.h / 2, "Brak danych", 0.5, 0.5);
}

static void legend(cairo_t *cr, double x, double y, const char **names, const unsigned *colors, int n)
{
    font(cr, 12, 0);
    for (int i = 0; i < n; i++) {
        rgb(cr, colors[i]);
        cairo_rectangle(cr, x, y - 9, 12, 10);
        cairo_fill(cr);
        rgb(cr, C_TEXT2);
        text(cr, x + 17, y, names[i], 0, 0);
        x += 17 + text_w(cr, names[i]) + 20;
    }
}

/* ----------------------------------------------------- wykres liniowy */

static void line_chart(cairo_t *cr, rect_t r, const double *const *series, const char **names,
                       const unsigned *colors, int nser, size_t n, double dx, fmt_fn yfmt)
{
    double ymax = 0;
    for (int s = 0; s < nser; s++)
        for (size_t i = 0; i < n; i++) if (series[s][i] > ymax) ymax = series[s][i];
    if (n < 2 || ymax <= 0) { no_data(cr, r); return; }

    char buf[48];
    double step = nice_step(ymax, 5);
    double ytop = ceil(ymax / step) * step;

    /* szerokość etykiet osi Y */
    font(cr, 11, 0);
    double lw = 0;
    for (double v = 0; v <= ytop + step / 2; v += step) {
        double tw = text_w(cr, yfmt(v, buf, sizeof buf));
        if (tw > lw) lw = tw;
    }
    rect_t p = { r.x + lw + 10, r.y + 22, r.w - lw - 14, r.h - 22 - 22 };

    /* siatka + etykiety Y */
    cairo_set_line_width(cr, 1);
    for (double v = 0; v <= ytop + step / 2; v += step) {
        double y = p.y + p.h - v / ytop * p.h;
        rgb(cr, v == 0 ? C_AXIS : C_GRID);
        cairo_move_to(cr, p.x, floor(y) + 0.5);
        cairo_line_to(cr, p.x + p.w, floor(y) + 0.5);
        cairo_stroke(cr);
        rgb(cr, C_TEXT2);
        text(cr, p.x - 8, y, yfmt(v, buf, sizeof buf), 1, 0.4);
    }
    /* etykiety X (czas względny) */
    double span = dx * (double)(n - 1);
    double xs = nice_step(span, 6);
    rgb(cr, C_TEXT2);
    for (double t = 0; t <= span + xs / 1000; t += xs) {
        double x = p.x + t / span * p.w;
        text(cr, x, p.y + p.h + 16, fmt_reltime(t, buf, sizeof buf), t == 0 ? 0 : 0.5, 0);
    }

    /* serie: linia 2px, łączenie zaokrąglone */
    cairo_set_line_width(cr, 2);
    cairo_set_line_join(cr, CAIRO_LINE_JOIN_ROUND);
    for (int s = 0; s < nser; s++) {
        rgb(cr, colors[s]);
        for (size_t i = 0; i < n; i++) {
            double x = p.x + (double)i / (double)(n - 1) * p.w;
            double y = p.y + p.h - series[s][i] / ytop * p.h;
            if (i == 0) cairo_move_to(cr, x, y); else cairo_line_to(cr, x, y);
        }
        cairo_stroke(cr);
    }
    legend(cr, r.x, r.y + 6, names, colors, nser);
}

/* -------------------------------------------- słupki pionowe (grupowane) */

static void vbar_chart(cairo_t *cr, rect_t r, const char **labels, size_t ncat,
                       const double *vals /* [ser*ncat] */, int nser, const char **names,
                       const unsigned *colors, fmt_fn yfmt, int logscale, double fixed_max)
{
    double ymax = 0;
    for (size_t i = 0; i < ncat * (size_t)nser; i++) if (vals[i] > ymax) ymax = vals[i];
    if (ymax <= 0) { no_data(cr, r); return; }
    if (fixed_max > 0) ymax = fixed_max;

    char buf[48];
    font(cr, 11, 0);
    double top_off = nser > 1 ? 24 : 6;
    double ytop, step = 1;
    if (logscale) ytop = ceil(log10(ymax + 1));
    else { step = nice_step(ymax, 5); ytop = ceil(ymax / step) * step; }
    if (ytop <= 0) ytop = 1;

    double lw = 0;
    if (logscale) {
        for (int k = 0; k <= (int)ytop; k++) {
            double tw = text_w(cr, fmt_count(pow(10, k), buf, sizeof buf));
            if (tw > lw) lw = tw;
        }
    } else {
        for (double v = 0; v <= ytop + step / 2; v += step) {
            double tw = text_w(cr, yfmt(v, buf, sizeof buf));
            if (tw > lw) lw = tw;
        }
    }
    rect_t p = { r.x + lw + 10, r.y + top_off, r.w - lw - 14, r.h - top_off - 24 };

    cairo_set_line_width(cr, 1);
    if (logscale) {
        for (int k = 0; k <= (int)ytop; k++) {
            double y = p.y + p.h - k / ytop * p.h;
            rgb(cr, k == 0 ? C_AXIS : C_GRID);
            cairo_move_to(cr, p.x, floor(y) + 0.5); cairo_line_to(cr, p.x + p.w, floor(y) + 0.5);
            cairo_stroke(cr);
            rgb(cr, C_TEXT2);
            text(cr, p.x - 8, y, fmt_count(pow(10, k), buf, sizeof buf), 1, 0.4);
        }
    } else {
        for (double v = 0; v <= ytop + step / 2; v += step) {
            double y = p.y + p.h - v / ytop * p.h;
            rgb(cr, v == 0 ? C_AXIS : C_GRID);
            cairo_move_to(cr, p.x, floor(y) + 0.5); cairo_line_to(cr, p.x + p.w, floor(y) + 0.5);
            cairo_stroke(cr);
            rgb(cr, C_TEXT2);
            text(cr, p.x - 8, y, yfmt(v, buf, sizeof buf), 1, 0.4);
        }
    }

    double slot = p.w / (double)ncat;
    double group = slot * (nser > 1 ? 0.72 : 0.66);
    double gap = 2;
    double bw = (group - gap * (nser - 1)) / nser;
    if (bw > 56) bw = 56;
    double gw = bw * nser + gap * (nser - 1);

    for (size_t c = 0; c < ncat; c++) {
        double gx = p.x + slot * (double)c + (slot - gw) / 2;
        for (int s = 0; s < nser; s++) {
            double v = vals[(size_t)s * ncat + c];
            double fr = logscale ? log10(v + 1) / ytop : v / ytop;
            double bh = fr * p.h;
            if (v > 0 && bh < 1) bh = 1;
            rgb(cr, colors[s]);
            bar_path(cr, gx + s * (bw + gap), p.y + p.h - bh, bw, bh, 0);
            cairo_fill(cr);
            /* selektywne etykiety: tylko gdy jest jedna seria i mało kategorii */
            if (nser == 1 && ncat <= 12 && v > 0) {
                rgb(cr, C_TEXT2);
                font(cr, 10.5, 0);
                text(cr, gx + bw / 2, p.y + p.h - bh - 5,
                     yfmt == fmt_pct ? fmt_pct(v, buf, sizeof buf) : fmt_count(v, buf, sizeof buf),
                     0.5, 0);
                font(cr, 11, 0);
            }
        }
        rgb(cr, C_TEXT2);
        text(cr, p.x + slot * (double)c + slot / 2, p.y + p.h + 16, labels[c], 0.5, 0);
    }
    if (nser > 1) legend(cr, r.x, r.y + 6, names, colors, nser);
}

/* --------------------------------------------- słupki poziome (ranking) */

static void hbar_chart(cairo_t *cr, rect_t r, const char **labels, const double *vals, size_t n,
                       fmt_fn vfmt)
{
    double vmax = 0;
    for (size_t i = 0; i < n; i++) if (vals[i] > vmax) vmax = vals[i];
    if (!n || vmax <= 0) { no_data(cr, r); return; }

    char buf[48];
    font(cr, 12, 0);
    double lw = 0, vw = 0;
    for (size_t i = 0; i < n; i++) {
        double t = text_w(cr, labels[i]); if (t > lw) lw = t;
        t = text_w(cr, vfmt(vals[i], buf, sizeof buf)); if (t > vw) vw = t;
    }
    if (lw > r.w * 0.45) lw = r.w * 0.45;
    double x0 = r.x + lw + 12, wmax = r.w - lw - 12 - vw - 10;
    double row = r.h / (double)(n < 6 ? 6 : n);
    double bh = row * 0.62;
    if (bh > 22) bh = 22;

    for (size_t i = 0; i < n; i++) {
        double cy = r.y + row * (double)i + row / 2;
        rgb(cr, C_TEXT);
        text(cr, x0 - 12, cy, labels[i], 1, 0.4);
        double bw = vals[i] / vmax * wmax;
        if (bw < 1) bw = 1;
        rgb(cr, C_S1);
        bar_path(cr, x0, cy - bh / 2, bw, bh, 1);
        cairo_fill(cr);
        rgb(cr, C_TEXT2);
        text(cr, x0 + bw + 8, cy, vfmt(vals[i], buf, sizeof buf), 0, 0.4);
    }
    rgb(cr, C_AXIS);
    cairo_set_line_width(cr, 1);
    cairo_move_to(cr, floor(x0) + 0.5, r.y);
    cairo_line_to(cr, floor(x0) + 0.5, r.y + row * (double)n);
    cairo_stroke(cr);
}

/* ----------------------------------------------------- wykresy raportu */

static const char *fmt_bytes_d(double v, char *b, size_t n) { return fmt_bytes(v, b, n); }

static void draw_throughput(const analysis_t *a, cairo_t *cr, rect_t r, int pkts)
{
    size_t n = a->nbuckets;
    double *s0 = xmalloc(n * sizeof(double)), *s1 = xmalloc(n * sizeof(double));
    for (size_t i = 0; i < n; i++) {
        if (pkts) {
            s0[i] = a->tl_pkts[0][i] / a->interval;
            s1[i] = a->tl_pkts[1][i] / a->interval;
        } else {
            s0[i] = a->tl_bytes[0][i] * 8 / a->interval;
            s1[i] = a->tl_bytes[1][i] * 8 / a->interval;
        }
    }
    const double *ser[2] = { s0, s1 };
    const char *names[2] = { "TCP", "UDP" };
    unsigned col[2] = { C_S1, C_S2 };
    line_chart(cr, r, ser, names, col, 2, n, a->interval, pkts ? fmt_count : fmt_bits);
    free(s0); free(s1);
}

static void draw_proto_share(const analysis_t *a, cairo_t *cr, rect_t r)
{
    double tp = (double)(a->tcp_pkts + a->udp_pkts);
    double tb = (double)(a->tcp_bytes + a->udp_bytes);
    double tf = (double)(a->tcp_flows + a->udp_flows);
    if (tp <= 0) { no_data(cr, r); return; }
    double v[6] = {
        100 * a->tcp_pkts / tp, 100 * a->tcp_bytes / tb, tf > 0 ? 100 * a->tcp_flows / tf : 0,
        100 * a->udp_pkts / tp, 100 * a->udp_bytes / tb, tf > 0 ? 100 * a->udp_flows / tf : 0,
    };
    const char *labels[3] = { "Pakiety", "Bajty", "Przepływy" };
    const char *names[2] = { "TCP", "UDP" };
    unsigned col[2] = { C_S1, C_S2 };
    vbar_chart(cr, r, labels, 3, v, 2, names, col, fmt_pct, 0, 100);

    /* wartości nad słupkami - przy 2 seriach i 3 kategoriach to nadal czytelne */
}

static void draw_size_hist(const analysis_t *a, cairo_t *cr, rect_t r)
{
    static const char *labels[SIZE_BINS] = { "0", "100", "200", "300", "400", "500", "600",
        "700", "800", "900", "1000", "1100", "1200", "1300", "1400", "1500+" };
    double v[SIZE_BINS];
    for (int i = 0; i < SIZE_BINS; i++) v[i] = (double)a->size_hist[i];
    vbar_chart(cr, r, labels, SIZE_BINS, v, 1, NULL, (unsigned[]){ C_S1 }, fmt_count, 0, 0);
}

static void draw_top_hosts(const analysis_t *a, cairo_t *cr, rect_t r)
{
    size_t *idx = hosts_sorted_by_bytes(a);
    size_t n = a->nhosts < (size_t)a->topn ? a->nhosts : (size_t)a->topn;
    char (*lab)[64] = xmalloc((n ? n : 1) * 64);
    const char **lp = xmalloc((n ? n : 1) * sizeof(char *));
    double *v = xmalloc((n ? n : 1) * sizeof(double));
    for (size_t i = 0; i < n; i++) {
        const host_t *h = &a->hosts[idx[i]];
        addr_str(h->family, h->addr, lab[i], 64);
        lp[i] = lab[i];
        v[i] = (double)(h->tx_bytes + h->rx_bytes);
    }
    hbar_chart(cr, r, lp, v, n, fmt_bytes_d);
    free(idx); free(lab); free(lp); free(v);
}

static void draw_top_ports(const analysis_t *a, cairo_t *cr, rect_t r)
{
    size_t topn = (size_t)a->topn;
    int *pp = xcalloc(topn, sizeof(int)), *pr = xcalloc(topn, sizeof(int));
    double *v = xcalloc(topn, sizeof(double));
    size_t n = 0;
    /* wybór top-N przez wstawianie - 131072 kandydatów, N <= 50 */
    for (int pi = 0; pi < 2; pi++)
        for (int port = 0; port < 65536; port++) {
            double b = (double)a->port_bytes[pi][port];
            if (b <= 0) continue;
            if (n < topn || b > v[n - 1]) {
                size_t j = n < topn ? n++ : n - 1;
                while (j > 0 && v[j - 1] < b) { v[j] = v[j - 1]; pp[j] = pp[j - 1]; pr[j] = pr[j - 1]; j--; }
                v[j] = b; pp[j] = port; pr[j] = pi;
            }
        }
    char (*lab)[48] = xmalloc((n ? n : 1) * 48);
    const char **lp = xmalloc((n ? n : 1) * sizeof(char *));
    for (size_t i = 0; i < n; i++) {
        const char *s = service_name(pr[i] == 0 ? PROTO_TCP : PROTO_UDP, (uint16_t)pp[i]);
        snprintf(lab[i], 48, "%s/%d%s%s%s", pr[i] == 0 ? "tcp" : "udp", pp[i],
                 s ? " (" : "", s ? s : "", s ? ")" : "");
        lp[i] = lab[i];
    }
    hbar_chart(cr, r, lp, v, n, fmt_bytes_d);
    free(pp); free(pr); free(v); free(lab); free(lp);
}

static void draw_tcp_flags(const analysis_t *a, cairo_t *cr, rect_t r)
{
    const char *labels[] = { "SYN", "SYN/ACK", "ACK", "PSH", "FIN", "RST", "URG", "ECE", "CWR" };
    double v[] = {
        (double)(a->flag_cnt[1] - a->synack_cnt), (double)a->synack_cnt, (double)a->flag_cnt[4],
        (double)a->flag_cnt[3], (double)a->flag_cnt[0], (double)a->flag_cnt[2],
        (double)a->flag_cnt[5], (double)a->flag_cnt[6], (double)a->flag_cnt[7],
    };
    vbar_chart(cr, r, labels, 9, v, 1, NULL, (unsigned[]){ C_S1 }, fmt_count, 1, 0);
}

static void draw_conn_states(const analysis_t *a, cairo_t *cr, rect_t r)
{
    const char *lp[CC__COUNT];
    double v[CC__COUNT];
    size_t n = 0;
    for (int c = 0; c < CC__COUNT; c++) {
        if (!a->class_cnt[c]) continue;
        lp[n] = conn_class_name[c];
        v[n++] = (double)a->class_cnt[c];
    }
    hbar_chart(cr, r, lp, v, n, fmt_count);
}

static void draw_rtt(const analysis_t *a, cairo_t *cr, rect_t r)
{
    static const double edges[] = { 0.001, 0.005, 0.010, 0.025, 0.050, 0.100, 0.250, 0.500, 1.0 };
    static const char *labels[] = { "<1ms", "1-5", "5-10", "10-25", "25-50", "50-100",
                                     "100-250", "250-500", "0.5-1s", ">1s" };
    double v[10] = { 0 };
    for (size_t i = 0; i < a->rtt_n; i++) {
        int b = 0;
        while (b < 9 && a->rtts[i] >= edges[b]) b++;
        v[b]++;
    }
    vbar_chart(cr, r, labels, 10, v, 1, NULL, (unsigned[]){ C_S1 }, fmt_count, 0, 0);
}

static void draw_duration(const analysis_t *a, cairo_t *cr, rect_t r)
{
    static const double edges[] = { 0.01, 0.1, 1, 10, 60, 600 };
    static const char *labels[] = { "<10ms", "10-100ms", "0.1-1s", "1-10s", "10-60s",
                                    "1-10min", ">10min" };
    double v[14] = { 0 };   /* [0..6] TCP, [7..13] UDP */
    for (size_t i = 0; i < a->nflows; i++) {
        const flow_t *f = &a->flows[i];
        double d = f->last - f->first;
        int b = 0;
        while (b < 6 && d >= edges[b]) b++;
        v[(f->key.proto == PROTO_TCP ? 0 : 7) + b]++;
    }
    const char *names[2] = { "TCP", "UDP" };
    unsigned col[2] = { C_S1, C_S2 };
    vbar_chart(cr, r, labels, 7, v, 2, names, col, fmt_count, 0, 0);
}

void chart_draw(const analysis_t *a, chart_id_t id, cairo_t *cr, double w, double h)
{
    char sub[160], b1[32], b2[32], b3[32];
    sub[0] = 0;
    switch (id) {
    case CH_THROUGHPUT: case CH_PACKET_RATE:
        snprintf(sub, sizeof sub, "Czas od początku zapisu, przedział uśredniania %g s", a->interval);
        break;
    case CH_SIZE_HIST:
        snprintf(sub, sizeof sub, "Liczba pakietów TCP/UDP w przedziałach co 100 bajtów");
        break;
    case CH_TOP_HOSTS: case CH_TOP_PORTS:
        snprintf(sub, sizeof sub, "Top %d według łącznej liczby bajtów", a->topn);
        break;
    case CH_TCP_FLAGS:
        snprintf(sub, sizeof sub, "Liczba pakietów, oś logarytmiczna");
        break;
    case CH_CONN_STATES:
        snprintf(sub, sizeof sub, "Liczba przepływów: %s TCP, %s UDP",
                 fmt_count((double)a->tcp_flows, b1, sizeof b1),
                 fmt_count((double)a->udp_flows, b2, sizeof b2));
        break;
    case CH_RTT_HIST:
        snprintf(sub, sizeof sub, "Liczba połączeń wg czasu SYN -> SYN/ACK [ms]; mediana %s, p95 %s",
                 fmt_duration(a->rtt_p50, b1, sizeof b1), fmt_duration(a->rtt_p95, b2, sizeof b2));
        (void)b3;
        break;
    case CH_FLOW_DURATION:
        snprintf(sub, sizeof sub, "Liczba przepływów w przedziałach czasu trwania");
        break;
    case CH_PROTO_SHARE:
        snprintf(sub, sizeof sub, "Procent całego ruchu TCP+UDP");
        break;
    default: break;
    }
    cairo_save(cr);
    rect_t r = frame(cr, w, h, chart_title[id], sub);
    switch (id) {
    case CH_THROUGHPUT:    draw_throughput(a, cr, r, 0); break;
    case CH_PACKET_RATE:   draw_throughput(a, cr, r, 1); break;
    case CH_PROTO_SHARE:   draw_proto_share(a, cr, r); break;
    case CH_SIZE_HIST:     draw_size_hist(a, cr, r); break;
    case CH_TOP_HOSTS:     draw_top_hosts(a, cr, r); break;
    case CH_TOP_PORTS:     draw_top_ports(a, cr, r); break;
    case CH_TCP_FLAGS:     draw_tcp_flags(a, cr, r); break;
    case CH_CONN_STATES:   draw_conn_states(a, cr, r); break;
    case CH_RTT_HIST:      draw_rtt(a, cr, r); break;
    case CH_FLOW_DURATION: draw_duration(a, cr, r); break;
    default: break;
    }
    cairo_restore(cr);
}

#define PNG_W 800
#define PNG_H 450
#define PNG_SCALE 2

int chart_write_png(const analysis_t *a, chart_id_t id, const char *path)
{
    cairo_surface_t *s = cairo_image_surface_create(CAIRO_FORMAT_RGB24,
                                                    PNG_W * PNG_SCALE, PNG_H * PNG_SCALE);
    cairo_t *cr = cairo_create(s);
    cairo_scale(cr, PNG_SCALE, PNG_SCALE);
    chart_draw(a, id, cr, PNG_W, PNG_H);
    cairo_destroy(cr);
    cairo_status_t st = cairo_surface_write_to_png(s, path);
    cairo_surface_destroy(s);
    return st == CAIRO_STATUS_SUCCESS ? 0 : -1;
}
