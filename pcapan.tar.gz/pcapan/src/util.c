/* util.c - formatowanie i alokacja */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <arpa/inet.h>
#include "pcapan.h"

void *xmalloc(size_t n)
{
    void *p = malloc(n ? n : 1);
    if (!p) { fprintf(stderr, "pcapan: brak pamięci\n"); exit(2); }
    return p;
}

void *xcalloc(size_t n, size_t sz)
{
    void *p = calloc(n ? n : 1, sz ? sz : 1);
    if (!p) { fprintf(stderr, "pcapan: brak pamięci\n"); exit(2); }
    return p;
}

void *xrealloc(void *p, size_t n)
{
    void *q = realloc(p, n ? n : 1);
    if (!q) { fprintf(stderr, "pcapan: brak pamięci\n"); exit(2); }
    return q;
}

const char *addr_str(uint8_t family, const uint8_t *addr, char *buf, size_t n)
{
    if (!inet_ntop(family == 6 ? AF_INET6 : AF_INET, addr, buf, (socklen_t)n))
        snprintf(buf, n, "?");
    return buf;
}

const char *endpoint_str(uint8_t family, const uint8_t *addr, uint16_t port, char *buf, size_t n)
{
    char a[INET6_ADDRSTRLEN];
    addr_str(family, addr, a, sizeof a);
    if (family == 6) snprintf(buf, n, "[%s]:%u", a, port);
    else             snprintf(buf, n, "%s:%u", a, port);
    return buf;
}

const char *fmt_bytes(double v, char *buf, size_t n)
{
    const char *u[] = { "B", "KB", "MB", "GB", "TB" };
    int i = 0;
    while (v >= 1000.0 && i < 4) { v /= 1000.0; i++; }
    if (i == 0) snprintf(buf, n, "%.0f %s", v, u[i]);
    else        snprintf(buf, n, "%.*f %s", v < 10 ? 2 : (v < 100 ? 1 : 0), v, u[i]);
    return buf;
}

/* "12.5 tys." ale "10 tys." zamiast "10.0 tys." */
static void short_num(char *buf, size_t n, double v, const char *unit)
{
    if (v == (double)(long long)v) snprintf(buf, n, "%lld %s", (long long)v, unit);
    else                           snprintf(buf, n, "%.1f %s", v, unit);
}

const char *fmt_count(double v, char *buf, size_t n)
{
    if (v >= 1e9)      short_num(buf, n, round(v / 1e8) / 10, "mld");
    else if (v >= 1e6) short_num(buf, n, round(v / 1e5) / 10, "mln");
    else if (v >= 1e4) short_num(buf, n, round(v / 1e2) / 10, "tys.");
    else if (v == (double)(long long)v) snprintf(buf, n, "%lld", (long long)v);
    else               snprintf(buf, n, "%.2f", v);
    return buf;
}

const char *fmt_time(double ts, char *buf, size_t n)
{
    time_t t = (time_t)ts;
    struct tm tm;
    gmtime_r(&t, &tm);
    char tmp[32];
    strftime(tmp, sizeof tmp, "%Y-%m-%d %H:%M:%S", &tm);
    snprintf(buf, n, "%s.%03d UTC", tmp, (int)((ts - (double)t) * 1000.0));
    return buf;
}

const char *fmt_duration(double s, char *buf, size_t n)
{
    if (s < 0) s = 0;
    if (s < 1e-3)        snprintf(buf, n, "%.0f µs", s * 1e6);
    else if (s < 1)      snprintf(buf, n, "%.1f ms", s * 1e3);
    else if (s < 120)    snprintf(buf, n, "%.2f s", s);
    else if (s < 7200)   snprintf(buf, n, "%.1f min", s / 60);
    else                 snprintf(buf, n, "%.1f h", s / 3600);
    return buf;
}

/* Krótka lista dobrze znanych portów - tylko do etykiet na wykresach. */
const char *service_name(int proto, uint16_t port)
{
    static const struct { int proto; uint16_t port; const char *name; } tab[] = {
        { 6, 20, "ftp-data" }, { 6, 21, "ftp" }, { 6, 22, "ssh" }, { 6, 23, "telnet" },
        { 6, 25, "smtp" }, { 0, 53, "dns" }, { 17, 67, "dhcp" }, { 17, 68, "dhcp" },
        { 17, 69, "tftp" }, { 6, 80, "http" }, { 6, 110, "pop3" }, { 17, 123, "ntp" },
        { 6, 135, "msrpc" }, { 17, 137, "netbios" }, { 6, 139, "netbios" }, { 6, 143, "imap" },
        { 17, 161, "snmp" }, { 6, 179, "bgp" }, { 0, 389, "ldap" }, { 6, 443, "https" },
        { 17, 443, "quic" }, { 6, 445, "smb" }, { 17, 500, "ike" }, { 17, 514, "syslog" },
        { 6, 587, "submission" }, { 6, 636, "ldaps" }, { 6, 853, "dot" }, { 6, 993, "imaps" },
        { 6, 995, "pop3s" }, { 17, 1194, "openvpn" }, { 6, 1433, "mssql" }, { 17, 1900, "ssdp" },
        { 6, 3306, "mysql" }, { 6, 3389, "rdp" }, { 6, 4444, "?4444" }, { 17, 5353, "mdns" },
        { 6, 5432, "postgres" }, { 0, 5060, "sip" }, { 6, 5900, "vnc" }, { 6, 6379, "redis" },
        { 6, 6667, "irc" }, { 6, 8080, "http-alt" }, { 6, 8443, "https-alt" },
        { 0, 11211, "memcached" }, { 17, 51820, "wireguard" }, { 6, 27017, "mongodb" },
    };
    for (size_t i = 0; i < sizeof tab / sizeof tab[0]; i++)
        if (tab[i].port == port && (tab[i].proto == 0 || tab[i].proto == proto))
            return tab[i].name;
    return NULL;
}
