# pcapan - analizator komunikacji TCP/UDP z plików pcap

Narzędzie w C dla Linuksa. Wczytuje pliki `.pcap`/`.pcapng` i generuje:

- `raport.pdf` - podsumowanie, wykryte nieprawidłowości, wykresy (wektorowo), tabele, metodologia,
- 10 wykresów `*.png`,
- `przeplywy.csv` - pełna lista przepływów do dalszej analizy (Excel, pandas).

## Zależności

| Biblioteka | Po co | Pakiet Debian/Ubuntu |
|---|---|---|
| libpcap | odczyt pcap/pcapng, filtry BPF | `libpcap-dev` |
| cairo | rysowanie PNG **i** PDF tym samym kodem | `libcairo2-dev` |
| libc, libm | reszta | - |

```sh
sudo apt install build-essential pkg-config libpcap-dev libcairo2-dev
make
```

## Użycie

```sh
./pcapan -o wynik zapis.pcap
./pcapan -o wynik -n 15 -f "not port 22" dzien1.pcap dzien2.pcapng
./pcapan --scan-ports 30 --spike-sigma 8 zapis.pcap     # mniej czułe progi
```

Kod wyjścia: `0` - OK, `3` - wykryto alarmy (przydatne w skryptach/CI), `1` - błąd.

## Architektura

```
main.c ──> libpcap ──> parser.c ──> analysis.c ──> anomaly.c
                       (ramka →     (przepływy,     (detektory
                        pakiet)      hosty, porty,   na przepływach)
                                     szereg czasowy)
                                          │
                     chart.c (cairo) ◄────┤
                     report.c (cairo-pdf, CSV) ◄───┘
```

| Moduł | Odpowiedzialność |
|---|---|
| `parser.c` | Ethernet (+VLAN/QinQ), Linux SLL/SLL2, RAW, loopback → IPv4/IPv6 (nagłówki rozszerzeń, fragmenty) → TCP/UDP. Bezstanowy, każde odczytanie pola po sprawdzeniu długości. |
| `analysis.c` | Tablice haszujące przepływów i hostów, liczniki, histogramy, szereg czasowy, klasyfikacja połączeń, RTT, retransmisje. |
| `anomaly.c` | Detektory nieprawidłowości z konfigurowalnymi progami. |
| `chart.c` | Wykresy liniowe/słupkowe rysowane na dowolnej powierzchni cairo. |
| `report.c` | Skład PDF (łamanie tekstu i stron, tabele), CSV, podsumowanie w konsoli. |

### Kluczowe decyzje projektowe i ich uzasadnienie

**Dwa przebiegi po plikach.** Pierwszy czyta tylko znaczniki czasu, więc znany jest zakres
czasu i rozmiar szeregu czasowego. Dzięki temu tablica nie jest realokowana, a pliki
nie muszą być podane w kolejności chronologicznej. Koszt to podwójny odczyt z dysku,
ale bez dekodowania.

**Przepływy dwukierunkowe z kanonicznym kluczem.** Klucz `(a, b)` jest uporządkowany tak,
że `a ≤ b`, więc pakiety A→B i B→A trafiają do jednego rekordu. Tylko wtedy da się
analizować handshake (SYN → SYN/ACK → ACK), mierzyć RTT i przypisać stronę klienta.

**Hasz z łańcuchami po indeksach, nie wskaźnikach.** Rekordy leżą w tablicy dynamicznej.
`realloc()` może ją przenieść, ale indeksy pozostają ważne, a gotową tablicę da się
bezpośrednio posortować (rankingi, tabele).

**Retransmisje przez numery sekwencyjne modulo 2³².** Dla każdego kierunku pamiętany jest
najwyższy koniec danych `seq + len`. Segment, który go nie przesuwa, to powtórzenie.
Porównanie `(int32_t)(x - y)` działa poprawnie także po przepełnieniu licznika (RFC 1982).

**Skanowanie liczone z nieudanych prób.** Przeglądarka też otwiera dziesiątki połączeń,
ale prawie wszystkie się udają. Skaner trafia głównie w zamknięte porty (RST, brak
odpowiedzi, SYN-scan bez trzeciego ACK). Po posortowaniu krotek `(src, dst, port)`
liczba unikalnych portów wychodzi z jednego liniowego przebiegu.

**Skoki ruchu: mediana + MAD zamiast średniej + σ.** Sam skok zawyża średnią i odchylenie,
przez co klasyczny z-score maskuje właśnie te próbki, których szukamy. Mediana i MAD
są na to odporne. Okno ma co najmniej 1 s, bo TCP z natury wysyła serie segmentów
w ciągu milisekund.

**Cairo dla PNG i PDF.** Jedna funkcja `chart_draw(cr, w, h)` rysuje wykres na dowolnej
powierzchni. PNG to `cairo_image_surface`, PDF to `cairo_pdf_surface`, więc wykresy
w raporcie są wektorowe i nie ma zależności od gnuplota, Pythona ani LaTeX-a.

## Wykrywane nieprawidłowości

| Detektor | Zasada | Domyślny próg |
|---|---|---|
| Skanowanie portów (pionowe) | 1 źródło → 1 cel, wiele portów, nieudane próby | ≥ 15 portów |
| Skanowanie sieci (poziome) | 1 źródło → wiele celów, ten sam port | ≥ 15 hostów |
| SYN flood | półotwarte/bez odpowiedzi do jednej usługi; liczba źródeł wskazuje spoofing | ≥ 100 |
| Niepoprawne flagi TCP | NULL, XMAS (FIN+PSH+URG), SYN+FIN | > 0 |
| Dużo resetów | udział połączeń zakończonych RST | > 30% |
| Retransmisje | globalnie i per przepływ (min. 20 segmentów) | > 2% / > 5% |
| Zero window | odbiorca ogłasza okno 0 | > 0 |
| Skok natężenia | pkt/s > mediana + 6·MAD, > 3× mediana, > 100 pkt/s | - |
| Wzmocnienie UDP | odpowiedź/zapytanie (DNS, NTP, memcached…) | ≥ 10×, ≥ 50 KB |
| Intensywny strumień UDP | jeden przepływ UDP | > 1000 pkt/s |
| Wolny handshake | SYN → SYN/ACK | > 1 s |
| Ryzykowne usługi | Telnet, FTP, POP3/IMAP bez TLS, porty 4444/6667/31337 | ruch z danymi |
| Uszkodzone pakiety, fragmentacja | obcięte/błędne nagłówki, > 5% fragmentów | - |

## Testy

```sh
pip install scapy
make test          # generuje 5 scenariuszy i uruchamia analizę
make asan-test     # AddressSanitizer + UBSan na wszystkich próbkach
make memcheck      # valgrind
```

| Plik testowy | Oczekiwany wynik |
|---|---|
| `normal.pcap` | 0 nieprawidłowości |
| `portscan.pcap` | skan pionowy, skan poziomy, NULL/XMAS, dużo RST |
| `synflood.pcap` | SYN flood z 800 źródeł |
| `amplification.pcap` | wzmocnienie DNS ~61× |
| `mixed.pcap` | wszystko powyżej + retransmisje, zero window, strumień UDP, telnet, IPv6, VLAN |

Odporność sprawdzono pod ASan/UBSan na plikach obciętych, pustych, niebędących
pcapem oraz z losowo uszkodzonymi bajtami w każdym pakiecie: bez błędów pamięci.

## Ograniczenia

- Z jednego punktu przechwytywania retransmisji nie da się odróżnić od zmiany kolejności pakietów.
- RTT handshake to opóźnienie między punktem przechwytywania a serwerem, nie pełne RTT klient-serwer.
- Ruch szyfrowany (TLS, QUIC) jest analizowany tylko na podstawie nagłówków.
- Cała tablica przepływów jest w pamięci (~200 B/przepływ). Przy wielu milionach przepływów
  potrzebne byłoby wygaszanie nieaktywnych przepływów (timeout).
